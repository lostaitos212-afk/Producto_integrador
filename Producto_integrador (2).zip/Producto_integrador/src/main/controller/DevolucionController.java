package main.controller;

import main.dao.DevolucionDAO;
import main.view.MainView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class DevolucionController implements ActionListener {

    private MainView vista;

    private DevolucionDAO devolucionDAO =
            new DevolucionDAO();

    public DevolucionController(MainView vista) {

        this.vista = vista;

        if (vista.btnRegistrarDevolucion != null) {
            vista.btnRegistrarDevolucion.addActionListener(this);
        }

        if (vista.btnVerDevoluciones != null) {
            vista.btnVerDevoluciones.addActionListener(this);
        }

        if (vista.btnDevCantidadMenos != null) {
            vista.btnDevCantidadMenos.addActionListener(this);
        }

        if (vista.btnDevCantidadMas != null) {
            vista.btnDevCantidadMas.addActionListener(this);
        }

        cargarHistorial();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnDevCantidadMenos) {

            cambiarCantidadDevolucion(-1);

        } else if (e.getSource() == vista.btnDevCantidadMas) {

            cambiarCantidadDevolucion(1);

        } else if (e.getSource() == vista.btnRegistrarDevolucion) {

            registrarDevolucion();

        } else if (e.getSource() == vista.btnVerDevoluciones) {

            cargarHistorial();
        }
    }

    private void cambiarCantidadDevolucion(int cambio) {

        try {

            String texto =
                    vista.txtDevCantidad
                            .getText()
                            .trim();

            int cantidad;

            if (texto.isEmpty()) {

                cantidad = 1;

            } else {

                cantidad =
                        Integer.parseInt(texto);
            }

            cantidad += cambio;

            if (cantidad < 1) {

                cantidad = 1;
            }

            vista.txtDevCantidad.setText(
                    String.valueOf(cantidad)
            );

        } catch (NumberFormatException e) {

            vista.txtDevCantidad.setText("1");
        }
    }

    private void registrarDevolucion() {

        String folio =
                vista.txtDevFolio
                        .getText()
                        .trim();

        String codigo =
                vista.txtDevCodigo
                        .getText()
                        .trim();

        String cantidadTexto =
                vista.txtDevCantidad
                        .getText()
                        .trim();

        String motivo =
                vista.txtDevMotivo
                        .getText()
                        .trim();

        if (folio.isEmpty()
                || codigo.isEmpty()
                || cantidadTexto.isEmpty()
                || motivo.isEmpty()) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Complete todos los campos de la devolución."
            );

            return;
        }

        try {

            int cantidad =
                    Integer.parseInt(cantidadTexto);

            if (cantidad <= 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "La cantidad debe ser mayor a 0."
                );

                return;
            }

            boolean existe =
                    devolucionDAO.productoExisteEnVenta(
                            folio,
                            codigo
                    );

            if (existe == false) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Ese producto no pertenece al folio de venta indicado."
                );

                return;
            }

            int cantidadVendida =
                    devolucionDAO.obtenerCantidadVendida(
                            folio,
                            codigo
                    );

            int cantidadDevuelta =
                    devolucionDAO.obtenerCantidadDevuelta(
                            folio,
                            codigo
                    );

            int disponibleParaDevolver =
                    cantidadVendida - cantidadDevuelta;

            if (disponibleParaDevolver <= 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Este producto ya fue devuelto completamente.\n"
                                + "No se puede registrar otro reembolso para el mismo producto."
                );

                return;
            }

            if (cantidad > disponibleParaDevolver) {

                JOptionPane.showMessageDialog(
                        vista,
                        "No puedes devolver más unidades de las vendidas.\n\n"
                                + "Cantidad vendida: "
                                + cantidadVendida
                                + "\nYa devueltas: "
                                + cantidadDevuelta
                                + "\nDisponible para devolver: "
                                + disponibleParaDevolver
                );

                return;
            }

            double precioUnitario =
                    devolucionDAO.obtenerPrecioUnitarioVendido(
                            folio,
                            codigo
                    );

            double montoReembolso =
                    precioUnitario * cantidad;

            int confirmar =
                    JOptionPane.showConfirmDialog(
                            vista,
                            "Se registrará la devolución y el reembolso.\n\n"
                                    + "Folio: "
                                    + folio
                                    + "\nProducto: "
                                    + codigo
                                    + "\nCantidad: "
                                    + cantidad
                                    + "\nMonto aproximado a reembolsar: $"
                                    + String.format("%.2f", montoReembolso)
                                    + "\n\n¿Deseas continuar?",
                            "Confirmar devolución",
                            JOptionPane.YES_NO_OPTION
                    );

            if (confirmar != JOptionPane.YES_OPTION) {

                return;
            }

            boolean registrada =
                    devolucionDAO.registrarDevolucion(
                            folio,
                            codigo,
                            cantidad,
                            motivo
                    );

            if (registrada) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Devolución registrada correctamente.\n"
                                + "Reembolso registrado: SÍ\n"
                                + "El stock fue actualizado."
                );

                limpiarCampos();

                cargarHistorial();

            } else {

                JOptionPane.showMessageDialog(
                        vista,
                        "No se pudo registrar la devolución.\n"
                                + "Verifica que no se haya devuelto ya todo el producto."
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    vista,
                    "La cantidad debe ser numérica."
            );
        }
    }

    private void limpiarCampos() {

        vista.txtDevFolio.setText("");
        vista.txtDevCodigo.setText("");
        vista.txtDevCantidad.setText("1");
        vista.txtDevMotivo.setText("");
    }

    private void cargarHistorial() {

        String historial =
                devolucionDAO.obtenerResumenDevoluciones();

        vista.txtResultadoDevolucion.setText(historial);
    }
}