package main.dao;

import main.util.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.List;

public class CompraDAO {

    private static class DetalleCompraTemporal {

        String codigoProducto;
        int cantidad;
        int stockActual;
        String nombreProducto;

        DetalleCompraTemporal(
                String codigoProducto,
                int cantidad,
                int stockActual,
                String nombreProducto
        ) {
            this.codigoProducto = codigoProducto;
            this.cantidad = cantidad;
            this.stockActual = stockActual;
            this.nombreProducto = nombreProducto;
        }
    }

    public boolean registrarEntradaMercancia(
            String codigoProducto,
            int cantidad,
            double precioCompraUnitario,
            String proveedor
    ) {

        String sqlCompra =
                "INSERT INTO compras " +
                "(proveedor, fecha, hora, total) " +
                "VALUES (?, ?, ?, ?)";

        String sqlDetalle =
                "INSERT INTO detalle_compras " +
                "(idCompra, codigoProducto, cantidad, precioCompraUnitario, subtotal) " +
                "VALUES (?, ?, ?, ?, ?)";

        String sqlActualizarProducto =
                "UPDATE productos " +
                "SET stock = stock + ?, precioCompra = ? " +
                "WHERE codigo = ?";

        double total =
                cantidad * precioCompraUnitario;

        String fecha =
                LocalDate.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "dd/MM/yyyy"
                                )
                        );

        String hora =
                LocalTime.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "HH:mm:ss"
                                )
                        );

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            conn.setAutoCommit(false);

            try (
                    PreparedStatement psCompra =
                            conn.prepareStatement(
                                    sqlCompra,
                                    Statement.RETURN_GENERATED_KEYS
                            );

                    PreparedStatement psDetalle =
                            conn.prepareStatement(sqlDetalle);

                    PreparedStatement psActualizar =
                            conn.prepareStatement(sqlActualizarProducto)
            ) {

                psCompra.setString(1, proveedor);
                psCompra.setString(2, fecha);
                psCompra.setString(3, hora);
                psCompra.setDouble(4, total);

                psCompra.executeUpdate();

                ResultSet rs =
                        psCompra.getGeneratedKeys();

                int idCompra = 0;

                if (rs.next()) {
                    idCompra = rs.getInt(1);
                }

                if (idCompra == 0) {

                    conn.rollback();

                    return false;
                }

                psDetalle.setInt(1, idCompra);
                psDetalle.setString(2, codigoProducto);
                psDetalle.setInt(3, cantidad);
                psDetalle.setDouble(4, precioCompraUnitario);
                psDetalle.setDouble(5, total);

                psDetalle.executeUpdate();

                psActualizar.setInt(1, cantidad);
                psActualizar.setDouble(2, precioCompraUnitario);
                psActualizar.setString(3, codigoProducto);

                int filasActualizadas =
                        psActualizar.executeUpdate();

                if (filasActualizadas == 0) {

                    conn.rollback();

                    return false;
                }

                conn.commit();

                return true;

            } catch (Exception e) {

                conn.rollback();

                e.printStackTrace();

                return false;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public String obtenerResumenCompras() {

        StringBuilder sb =
                new StringBuilder();

        String sql =
                "SELECT c.id, c.proveedor, c.fecha, c.hora, c.total, " +
                "d.codigoProducto, p.nombre, d.cantidad, d.precioCompraUnitario, d.subtotal " +
                "FROM compras c " +
                "INNER JOIN detalle_compras d ON c.id = d.idCompra " +
                "INNER JOIN productos p ON d.codigoProducto = p.codigo " +
                "ORDER BY c.id DESC";

        sb.append("============================================\n");
        sb.append("             HISTORIAL DE COMPRAS           \n");
        sb.append("============================================\n");

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                sb.append("No se pudo conectar a la base de datos.\n");

                return sb.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql);

                    ResultSet rs =
                            ps.executeQuery()
            ) {

                boolean hayDatos =
                        false;

                while (rs.next()) {

                    hayDatos = true;

                    sb.append("ID COMPRA: ")
                            .append(rs.getInt("id"))
                            .append("\n");

                    sb.append("Proveedor: ")
                            .append(rs.getString("proveedor"))
                            .append("\n");

                    sb.append("Producto: ")
                            .append(rs.getString("codigoProducto"))
                            .append(" - ")
                            .append(rs.getString("nombre"))
                            .append("\n");

                    sb.append("Cantidad comprada: ")
                            .append(rs.getInt("cantidad"))
                            .append("\n");

                    sb.append(
                            String.format(
                                    "Precio compra unitario: $%.2f\n",
                                    rs.getDouble("precioCompraUnitario")
                            )
                    );

                    sb.append(
                            String.format(
                                    "Subtotal: $%.2f\n",
                                    rs.getDouble("subtotal")
                            )
                    );

                    sb.append(
                            String.format(
                                    "Total compra: $%.2f\n",
                                    rs.getDouble("total")
                            )
                    );

                    sb.append("Fecha: ")
                            .append(rs.getString("fecha"))
                            .append("  Hora: ")
                            .append(rs.getString("hora"))
                            .append("\n");

                    sb.append("--------------------------------------------\n");
                }

                if (!hayDatos) {

                    sb.append("No hay compras registradas.\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            sb.append("Error al cargar historial de compras.\n");
        }

        return sb.toString();
    }

    public boolean compraExiste(int idCompra) {

        String sql =
                "SELECT id FROM compras WHERE id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setInt(1, idCompra);

                ResultSet rs =
                        ps.executeQuery();

                return rs.next();
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public boolean cancelarCompra(int idCompra) {

        String sqlDetalles =
                "SELECT d.codigoProducto, d.cantidad, p.stock, p.nombre " +
                "FROM detalle_compras d " +
                "INNER JOIN productos p ON d.codigoProducto = p.codigo " +
                "WHERE d.idCompra = ?";

        String sqlRestarStock =
                "UPDATE productos " +
                "SET stock = stock - ? " +
                "WHERE codigo = ?";

        String sqlEliminarDetalle =
                "DELETE FROM detalle_compras " +
                "WHERE idCompra = ?";

        String sqlEliminarCompra =
                "DELETE FROM compras " +
                "WHERE id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            conn.setAutoCommit(false);

            try (
                    PreparedStatement psDetalles =
                            conn.prepareStatement(sqlDetalles);

                    PreparedStatement psRestarStock =
                            conn.prepareStatement(sqlRestarStock);

                    PreparedStatement psEliminarDetalle =
                            conn.prepareStatement(sqlEliminarDetalle);

                    PreparedStatement psEliminarCompra =
                            conn.prepareStatement(sqlEliminarCompra)
            ) {

                psDetalles.setInt(1, idCompra);

                ResultSet rs =
                        psDetalles.executeQuery();

                List<DetalleCompraTemporal> detalles =
                        new ArrayList<>();

                while (rs.next()) {

                    detalles.add(
                            new DetalleCompraTemporal(
                                    rs.getString("codigoProducto"),
                                    rs.getInt("cantidad"),
                                    rs.getInt("stock"),
                                    rs.getString("nombre")
                            )
                    );
                }

                if (detalles.isEmpty()) {

                    conn.rollback();

                    return false;
                }

                for (DetalleCompraTemporal d : detalles) {

                    if (d.stockActual < d.cantidad) {

                        conn.rollback();

                        return false;
                    }
                }

                for (DetalleCompraTemporal d : detalles) {

                    psRestarStock.setInt(1, d.cantidad);
                    psRestarStock.setString(2, d.codigoProducto);

                    int filas =
                            psRestarStock.executeUpdate();

                    if (filas == 0) {

                        conn.rollback();

                        return false;
                    }
                }

                psEliminarDetalle.setInt(1, idCompra);
                psEliminarDetalle.executeUpdate();

                psEliminarCompra.setInt(1, idCompra);

                int compraEliminada =
                        psEliminarCompra.executeUpdate();

                if (compraEliminada == 0) {

                    conn.rollback();

                    return false;
                }

                conn.commit();

                return true;

            } catch (Exception e) {

                conn.rollback();

                e.printStackTrace();

                return false;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public String obtenerDetalleCancelacion(int idCompra) {

        StringBuilder sb =
                new StringBuilder();

        String sql =
                "SELECT c.id, c.proveedor, c.fecha, c.hora, " +
                "d.codigoProducto, p.nombre, d.cantidad, d.subtotal " +
                "FROM compras c " +
                "INNER JOIN detalle_compras d ON c.id = d.idCompra " +
                "INNER JOIN productos p ON d.codigoProducto = p.codigo " +
                "WHERE c.id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                return "No se pudo conectar a la base de datos.";
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setInt(1, idCompra);

                ResultSet rs =
                        ps.executeQuery();

                boolean hayDatos =
                        false;

                while (rs.next()) {

                    hayDatos = true;

                    sb.append("ID compra: ")
                            .append(rs.getInt("id"))
                            .append("\n");

                    sb.append("Proveedor: ")
                            .append(rs.getString("proveedor"))
                            .append("\n");

                    sb.append("Producto: ")
                            .append(rs.getString("codigoProducto"))
                            .append(" - ")
                            .append(rs.getString("nombre"))
                            .append("\n");

                    sb.append("Cantidad a retirar del stock: ")
                            .append(rs.getInt("cantidad"))
                            .append("\n");

                    sb.append(
                            String.format(
                                    "Subtotal compra: $%.2f\n",
                                    rs.getDouble("subtotal")
                            )
                    );

                    sb.append("Fecha: ")
                            .append(rs.getString("fecha"))
                            .append("  Hora: ")
                            .append(rs.getString("hora"))
                            .append("\n");

                    sb.append("--------------------------------------------\n");
                }

                if (!hayDatos) {

                    sb.append("No se encontró la compra indicada.");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            sb.append("Error al consultar compra.");
        }

        return sb.toString();
    }
}