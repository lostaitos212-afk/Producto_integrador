package main.dao;

import main.model.Venta;
import main.model.DetalleVenta;
import main.util.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    public boolean guardarVenta(Venta venta) {

        String sqlVenta =
                "INSERT INTO ventas " +
                "(folio, subtotal, descuento, total, metodoPago, montoRecibido, cambio, fecha, hora) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        String sqlDetalle =
                "INSERT INTO detalle_ventas " +
                "(folioVenta, codigoProducto, cantidad, subtotal) " +
                "VALUES (?, ?, ?, ?)";

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            conn.setAutoCommit(false);

            try (
                    PreparedStatement psVenta =
                            conn.prepareStatement(sqlVenta);

                    PreparedStatement psDetalle =
                            conn.prepareStatement(sqlDetalle)
            ) {

                psVenta.setString(1, venta.getFolio());
                psVenta.setDouble(2, venta.getSubtotal());
                psVenta.setDouble(3, venta.getDescuento());
                psVenta.setDouble(4, venta.getTotal());
                psVenta.setString(5, venta.getMetodoPago());
                psVenta.setDouble(6, venta.getMontoRecibido());
                psVenta.setDouble(7, venta.getCambio());
                psVenta.setString(8, venta.getFecha());
                psVenta.setString(9, venta.getHora());

                psVenta.executeUpdate();

                for (DetalleVenta d : venta.getItems()) {

                    psDetalle.setString(1, venta.getFolio());
                    psDetalle.setString(2, d.getProducto().getCodigo());
                    psDetalle.setInt(3, d.getCantidad());
                    psDetalle.setDouble(4, d.getSubtotal());

                    psDetalle.executeUpdate();
                }

                conn.commit();

                return true;

            } catch (Exception e) {

                conn.rollback();

                e.printStackTrace();

                return false;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public List<String> obtenerFolios() {

        List<String> folios =
                new ArrayList<>();

        String sql =
                "SELECT folio FROM ventas " +
                "ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') DESC, hora DESC";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return folios;
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql);

                    ResultSet rs =
                            ps.executeQuery()
            ) {

                while (rs.next()) {

                    folios.add(
                            rs.getString("folio")
                    );
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return folios;
    }

    public String obtenerTicketPorFolio(String folio) {

        StringBuilder ticket =
                new StringBuilder();

        String sqlVenta =
                "SELECT * FROM ventas WHERE folio = ?";

        String sqlDetalle =
                "SELECT d.codigoProducto, d.cantidad, d.subtotal, p.nombre " +
                "FROM detalle_ventas d " +
                "INNER JOIN productos p ON d.codigoProducto = p.codigo " +
                "WHERE d.folioVenta = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return "No se pudo conectar a la base de datos.";
            }

            try (
                    PreparedStatement psVenta =
                            conn.prepareStatement(sqlVenta);

                    PreparedStatement psDetalle =
                            conn.prepareStatement(sqlDetalle)
            ) {

                psVenta.setString(1, folio);

                ResultSet rsVenta =
                        psVenta.executeQuery();

                if (rsVenta.next()) {

                    ticket.append("============================================\n");
                    ticket.append("               MEGAPOS EXPRESS              \n");
                    ticket.append("============================================\n");

                    ticket.append("FOLIO: ")
                            .append(rsVenta.getString("folio"))
                            .append("\n");

                    ticket.append("FECHA: ")
                            .append(rsVenta.getString("fecha"))
                            .append("   HORA: ")
                            .append(rsVenta.getString("hora"))
                            .append("\n");

                    ticket.append("MÉTODO DE PAGO: ")
                            .append(rsVenta.getString("metodoPago"))
                            .append("\n");

                    ticket.append("--------------------------------------------\n");

                    ticket.append(
                            String.format(
                                    "%-5s %-7s %-13s %-8s %-8s\n",
                                    "CANT",
                                    "COD",
                                    "PRODUCTO",
                                    "PRECIO",
                                    "SUBT"
                            )
                    );

                    ticket.append("--------------------------------------------\n");

                    psDetalle.setString(1, folio);

                    ResultSet rsDetalle =
                            psDetalle.executeQuery();

                    while (rsDetalle.next()) {

                        String codigo =
                                rsDetalle.getString("codigoProducto");

                        String nombre =
                                rsDetalle.getString("nombre");

                        int cantidad =
                                rsDetalle.getInt("cantidad");

                        double subtotal =
                                rsDetalle.getDouble("subtotal");

                        double precioUnitario =
                                0.0;

                        if (cantidad > 0) {

                            precioUnitario =
                                    subtotal / cantidad;
                        }

                        if (nombre.length() > 12) {

                            nombre =
                                    nombre.substring(0, 12);
                        }

                        ticket.append(
                                String.format(
                                        "%-5d %-7s %-13s $%-7.2f $%-7.2f\n",
                                        cantidad,
                                        codigo,
                                        nombre,
                                        precioUnitario,
                                        subtotal
                                )
                        );
                    }

                    ticket.append("--------------------------------------------\n");

                    ticket.append(
                            String.format(
                                    "SUBTOTAL:                  $%.2f\n",
                                    rsVenta.getDouble("subtotal")
                            )
                    );

                    ticket.append(
                            String.format(
                                    "DESCUENTO:                 $%.2f\n",
                                    rsVenta.getDouble("descuento")
                            )
                    );

                    ticket.append(
                            String.format(
                                    "MONTO A PAGAR:             $%.2f\n",
                                    rsVenta.getDouble("total")
                            )
                    );

                    ticket.append(
                            String.format(
                                    "MONTO RECIBIDO:            $%.2f\n",
                                    rsVenta.getDouble("montoRecibido")
                            )
                    );

                    ticket.append(
                            String.format(
                                    "CAMBIO ENTREGADO:          $%.2f\n",
                                    rsVenta.getDouble("cambio")
                            )
                    );

                    ticket.append("============================================\n");
                    ticket.append("           GRACIAS POR SU COMPRA!           \n");
                    ticket.append("============================================\n");

                } else {

                    ticket.append("No se encontró el ticket.");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            ticket.append("Error al cargar ticket desde MySQL.");
        }

        return ticket.toString();
    }

    public String obtenerReportePorFecha(String fecha) {

        StringBuilder reporte =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, montoRecibido, cambio, hora " +
                "FROM ventas " +
                "WHERE fecha = ? " +
                "ORDER BY hora ASC";

        double totalDia =
                0.0;

        int contadorVentas =
                0;

        reporte.append("========================================\n");
        reporte.append("          REPORTE DE VENTAS             \n");
        reporte.append("========================================\n");
        reporte.append("FECHA: ").append(fecha).append("\n");
        reporte.append("----------------------------------------\n");

        reporte.append(
                String.format(
                        "%-18s %-10s %-10s %-8s\n",
                        "FOLIO",
                        "TOTAL",
                        "PAGO",
                        "HORA"
                )
        );

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                reporte.append("No se pudo conectar a la base de datos.\n");

                return reporte.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    String folio =
                            rs.getString("folio");

                    double total =
                            rs.getDouble("total");

                    String metodoPago =
                            rs.getString("metodoPago");

                    String hora =
                            rs.getString("hora");

                    totalDia += total;
                    contadorVentas++;

                    reporte.append(
                            String.format(
                                    "%-18s $%-9.2f %-10s %-8s\n",
                                    folio,
                                    total,
                                    metodoPago,
                                    hora
                            )
                    );
                }

                reporte.append("----------------------------------------\n");

                reporte.append("VENTAS REALIZADAS: ")
                        .append(contadorVentas)
                        .append("\n");

                reporte.append(
                        String.format(
                                "TOTAL VENDIDO: $%.2f\n",
                                totalDia
                        )
                );

                reporte.append("========================================\n");

                if (contadorVentas == 0) {

                    reporte.append("No hay ventas registradas en esta fecha.\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar reporte.\n");
        }

        return reporte.toString();
    }

    public String obtenerCSVPorFecha(String fecha) {

        StringBuilder csv =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, montoRecibido, cambio, fecha, hora " +
                "FROM ventas " +
                "WHERE fecha = ? " +
                "ORDER BY hora ASC";

        csv.append("Folio,Subtotal,Descuento,Total,MetodoPago,MontoRecibido,Cambio,Fecha,Hora\n");

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return csv.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    csv.append(rs.getString("folio")).append(",");
                    csv.append(rs.getDouble("subtotal")).append(",");
                    csv.append(rs.getDouble("descuento")).append(",");
                    csv.append(rs.getDouble("total")).append(",");
                    csv.append(rs.getString("metodoPago")).append(",");
                    csv.append(rs.getDouble("montoRecibido")).append(",");
                    csv.append(rs.getDouble("cambio")).append(",");
                    csv.append(rs.getString("fecha")).append(",");
                    csv.append(rs.getString("hora")).append("\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return csv.toString();
    }

    public String obtenerReportePorIntervalo(
            String fechaInicio,
            String fechaFin
    ) {

        StringBuilder reporte =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, montoRecibido, cambio, fecha, hora " +
                "FROM ventas " +
                "WHERE STR_TO_DATE(fecha, '%d/%m/%Y') " +
                "BETWEEN STR_TO_DATE(?, '%d/%m/%Y') " +
                "AND STR_TO_DATE(?, '%d/%m/%Y') " +
                "ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') ASC, hora ASC";

        double totalGeneral =
                0.0;

        int contadorVentas =
                0;

        reporte.append("============================================\n");
        reporte.append("        REPORTE DE VENTAS POR INTERVALO     \n");
        reporte.append("============================================\n");
        reporte.append("DESDE: ").append(fechaInicio).append("\n");
        reporte.append("HASTA: ").append(fechaFin).append("\n");
        reporte.append("--------------------------------------------\n");

        reporte.append(
                String.format(
                        "%-12s %-18s %-10s %-10s %-8s\n",
                        "FECHA",
                        "FOLIO",
                        "TOTAL",
                        "PAGO",
                        "HORA"
                )
        );

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                reporte.append("No se pudo conectar a la base de datos.\n");

                return reporte.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, fechaInicio);
                ps.setString(2, fechaFin);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    String fecha =
                            rs.getString("fecha");

                    String folio =
                            rs.getString("folio");

                    double total =
                            rs.getDouble("total");

                    String metodoPago =
                            rs.getString("metodoPago");

                    String hora =
                            rs.getString("hora");

                    totalGeneral += total;
                    contadorVentas++;

                    reporte.append(
                            String.format(
                                    "%-12s %-18s $%-9.2f %-10s %-8s\n",
                                    fecha,
                                    folio,
                                    total,
                                    metodoPago,
                                    hora
                            )
                    );
                }

                reporte.append("--------------------------------------------\n");

                reporte.append("VENTAS REALIZADAS: ")
                        .append(contadorVentas)
                        .append("\n");

                reporte.append(
                        String.format(
                                "TOTAL VENDIDO EN INTERVALO: $%.2f\n",
                                totalGeneral
                        )
                );

                reporte.append("============================================\n");

                if (contadorVentas == 0) {

                    reporte.append("No hay ventas registradas en ese intervalo.\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar reporte por intervalo.\n");
        }

        return reporte.toString();
    }

    public String obtenerCSVPorIntervalo(
            String fechaInicio,
            String fechaFin
    ) {

        StringBuilder csv =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, montoRecibido, cambio, fecha, hora " +
                "FROM ventas " +
                "WHERE STR_TO_DATE(fecha, '%d/%m/%Y') " +
                "BETWEEN STR_TO_DATE(?, '%d/%m/%Y') " +
                "AND STR_TO_DATE(?, '%d/%m/%Y') " +
                "ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') ASC, hora ASC";

        csv.append("Folio,Subtotal,Descuento,Total,MetodoPago,MontoRecibido,Cambio,Fecha,Hora\n");

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return csv.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, fechaInicio);
                ps.setString(2, fechaFin);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    csv.append(rs.getString("folio")).append(",");
                    csv.append(rs.getDouble("subtotal")).append(",");
                    csv.append(rs.getDouble("descuento")).append(",");
                    csv.append(rs.getDouble("total")).append(",");
                    csv.append(rs.getString("metodoPago")).append(",");
                    csv.append(rs.getDouble("montoRecibido")).append(",");
                    csv.append(rs.getDouble("cambio")).append(",");
                    csv.append(rs.getString("fecha")).append(",");
                    csv.append(rs.getString("hora")).append("\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return csv.toString();
    }

    public String obtenerReporteProductosVendidos(String fecha) {

        StringBuilder reporte =
                new StringBuilder();

        String sql =
                "SELECT p.codigo, p.nombre, " +
                "SUM(d.cantidad) AS cantidadVendida, " +
                "SUM(d.subtotal) AS totalGenerado " +
                "FROM detalle_ventas d " +
                "INNER JOIN productos p ON d.codigoProducto = p.codigo " +
                "INNER JOIN ventas v ON d.folioVenta = v.folio " +
                "WHERE v.fecha = ? " +
                "GROUP BY p.codigo, p.nombre " +
                "ORDER BY cantidadVendida DESC";

        reporte.append("============================================\n");
        reporte.append("       REPORTE PRODUCTOS VENDIDOS           \n");
        reporte.append("============================================\n");
        reporte.append("FECHA: ").append(fecha).append("\n");
        reporte.append("--------------------------------------------\n");

        reporte.append(
                String.format(
                        "%-8s %-18s %-8s %-10s\n",
                        "CODIGO",
                        "PRODUCTO",
                        "CANT",
                        "TOTAL"
                )
        );

        reporte.append("--------------------------------------------\n");

        double totalGeneral =
                0.0;

        int productosDistintos =
                0;

        int piezasVendidas =
                0;

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                reporte.append("No se pudo conectar a la base de datos.\n");

                return reporte.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    productosDistintos++;

                    String codigo =
                            rs.getString("codigo");

                    String nombre =
                            rs.getString("nombre");

                    int cantidad =
                            rs.getInt("cantidadVendida");

                    double total =
                            rs.getDouble("totalGenerado");

                    piezasVendidas += cantidad;
                    totalGeneral += total;

                    if (nombre.length() > 16) {

                        nombre =
                                nombre.substring(0, 16);
                    }

                    reporte.append(
                            String.format(
                                    "%-8s %-18s %-8d $%-9.2f\n",
                                    codigo,
                                    nombre,
                                    cantidad,
                                    total
                            )
                    );
                }

                reporte.append("--------------------------------------------\n");
                reporte.append("PRODUCTOS DISTINTOS: ")
                        .append(productosDistintos)
                        .append("\n");

                reporte.append("PIEZAS VENDIDAS: ")
                        .append(piezasVendidas)
                        .append("\n");

                reporte.append(
                        String.format(
                                "TOTAL GENERADO: $%.2f\n",
                                totalGeneral
                        )
                );

                reporte.append("============================================\n");

                if (productosDistintos == 0) {

                    reporte.append("No hay productos vendidos en esta fecha.\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar reporte de productos vendidos.\n");
        }

        return reporte.toString();
    }

    public String obtenerCSVProductosVendidos(String fecha) {

        StringBuilder csv =
                new StringBuilder();

        String sql =
                "SELECT p.codigo, p.nombre, " +
                "SUM(d.cantidad) AS cantidadVendida, " +
                "SUM(d.subtotal) AS totalGenerado " +
                "FROM detalle_ventas d " +
                "INNER JOIN productos p ON d.codigoProducto = p.codigo " +
                "INNER JOIN ventas v ON d.folioVenta = v.folio " +
                "WHERE v.fecha = ? " +
                "GROUP BY p.codigo, p.nombre " +
                "ORDER BY cantidadVendida DESC";

        csv.append("Fecha,Codigo,Producto,CantidadVendida,TotalGenerado\n");

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return csv.toString();
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    csv.append(fecha).append(",");
                    csv.append(rs.getString("codigo")).append(",");
                    csv.append(rs.getString("nombre")).append(",");
                    csv.append(rs.getInt("cantidadVendida")).append(",");
                    csv.append(rs.getDouble("totalGenerado")).append("\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return csv.toString();
    }
}