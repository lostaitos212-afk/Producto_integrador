package main.dao;

import main.model.DetalleVenta;
import main.model.Venta;
import main.util.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    public VentaDAO() {
        prepararEstructuraMinima();
    }

    private void prepararEstructuraMinima() {

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return;
            }

            try (
                    Statement st = conn.createStatement()
            ) {

                st.executeUpdate(
                        "CREATE TABLE IF NOT EXISTS detalle_ventas (" +
                                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                                "folioVenta VARCHAR(50) NOT NULL, " +
                                "codigoProducto VARCHAR(50) NOT NULL, " +
                                "cantidad INT NOT NULL, " +
                                "subtotal DOUBLE NOT NULL DEFAULT 0" +
                                ")"
                );

                ejecutarAlterSeguro(
                        st,
                        "ALTER TABLE ventas ADD COLUMN montoRecibido DOUBLE NOT NULL DEFAULT 0"
                );

                ejecutarAlterSeguro(
                        st,
                        "ALTER TABLE ventas ADD COLUMN ticketTexto TEXT"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void ejecutarAlterSeguro(
            Statement st,
            String sql
    ) {

        try {

            st.executeUpdate(sql);

        } catch (Exception e) {

            /*
             * Si la columna ya existe, MySQL marca error.
             * No afecta el funcionamiento.
             */
        }
    }

    public boolean guardarVenta(Venta venta) {

        prepararEstructuraMinima();

        String ticketTexto =
                construirTicketDesdeObjeto(venta);

        String sqlVenta =
                "INSERT INTO ventas " +
                        "(folio, subtotal, descuento, total, metodoPago, montoRecibido, cambio, fecha, hora, ticketTexto) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        String sqlDetalle =
                "INSERT INTO detalle_ventas " +
                        "(folioVenta, codigoProducto, cantidad, subtotal) " +
                        "VALUES (?, ?, ?, ?)";

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            conn.setAutoCommit(false);

            try (
                    PreparedStatement psVenta = conn.prepareStatement(sqlVenta);
                    PreparedStatement psDetalle = conn.prepareStatement(sqlDetalle)
            ) {

                psVenta.setString(1, venta.getFolio());
                psVenta.setDouble(2, venta.getSubtotal());
                psVenta.setDouble(3, venta.getDescuento());
                psVenta.setDouble(4, venta.getTotal());
                psVenta.setString(5, venta.getMetodoPago());
                psVenta.setDouble(6, venta.getMontoRecibido());
                psVenta.setDouble(7, venta.getCambio());
                psVenta.setString(8, venta.getFecha());
                psVenta.setString(9, venta.getHora());
                psVenta.setString(10, ticketTexto);

                psVenta.executeUpdate();

                for (DetalleVenta d : venta.getDetalles()) {

                    double subtotalDetalle =
                            d.getCantidad()
                                    * d.getProducto().getPrecioVenta();

                    psDetalle.setString(1, venta.getFolio());
                    psDetalle.setString(2, d.getProducto().getCodigo());
                    psDetalle.setInt(3, d.getCantidad());
                    psDetalle.setDouble(4, subtotalDetalle);

                    psDetalle.executeUpdate();
                }

                conn.commit();

                return true;

            } catch (Exception e) {

                conn.rollback();

                e.printStackTrace();

                return false;

            } finally {

                conn.setAutoCommit(true);
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    private String construirTicketDesdeObjeto(Venta venta) {

        StringBuilder ticket =
                new StringBuilder();

        ticket.append("============================================\n");
        ticket.append("                MEGAPOS TICKET              \n");
        ticket.append("============================================\n");

        ticket.append("FOLIO: ")
                .append(venta.getFolio())
                .append("\n");

        ticket.append("FECHA: ")
                .append(venta.getFecha())
                .append("   HORA: ")
                .append(venta.getHora())
                .append("\n");

        ticket.append("MÉTODO DE PAGO: ")
                .append(venta.getMetodoPago())
                .append("\n");

        ticket.append("--------------------------------------------\n");

        ticket.append(
                String.format(
                        "%-5s %-8s %-14s %-8s %-8s\n",
                        "CANT",
                        "COD",
                        "PRODUCTO",
                        "P.UNIT",
                        "SUBT"
                )
        );

        ticket.append("--------------------------------------------\n");

        for (DetalleVenta d : venta.getDetalles()) {

            String codigo =
                    d.getProducto().getCodigo();

            String nombre =
                    d.getProducto().getNombre();

            int cantidad =
                    d.getCantidad();

            double precio =
                    d.getProducto().getPrecioVenta();

            double subtotal =
                    cantidad * precio;

            if (nombre == null) {
                nombre = "Producto";
            }

            if (nombre.length() > 13) {
                nombre = nombre.substring(0, 13);
            }

            ticket.append(
                    String.format(
                            "%-5d %-8s %-14s $%-7.2f $%-7.2f\n",
                            cantidad,
                            codigo,
                            nombre,
                            precio,
                            subtotal
                    )
            );
        }

        ticket.append("--------------------------------------------\n");

        ticket.append(
                String.format(
                        "SUBTOTAL:                  $%.2f\n",
                        venta.getSubtotal()
                )
        );

        ticket.append(
                String.format(
                        "DESCUENTO:                 $%.2f\n",
                        venta.getDescuento()
                )
        );

        ticket.append(
                String.format(
                        "MONTO A PAGAR:             $%.2f\n",
                        venta.getTotal()
                )
        );

        ticket.append(
                String.format(
                        "MONTO RECIBIDO:            $%.2f\n",
                        venta.getMontoRecibido()
                )
        );

        ticket.append(
                String.format(
                        "CAMBIO:                    $%.2f\n",
                        venta.getCambio()
                )
        );

        ticket.append("============================================\n");
        ticket.append("            GRACIAS POR SU COMPRA           \n");
        ticket.append("============================================\n");

        return ticket.toString();
    }

    public List<String> obtenerFolios() {

        prepararEstructuraMinima();

        List<String> folios =
                new ArrayList<>();

        String sql =
                "SELECT folio " +
                        "FROM ventas " +
                        "ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') DESC, hora DESC";

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return folios;
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ResultSet rs = ps.executeQuery()
            ) {

                while (rs.next()) {

                    folios.add(
                            rs.getString("folio")
                    );
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return folios;
    }

    public String obtenerTicketPorFolio(String folio) {

        prepararEstructuraMinima();

        String ticketGuardado =
                obtenerTicketTextoGuardado(folio);

        if (ticketGuardado != null
                && ticketGuardado.trim().isEmpty() == false) {

            return ticketGuardado;
        }

        return reconstruirTicketDesdeBD(folio);
    }

    private String obtenerTicketTextoGuardado(String folio) {

        String sql =
                "SELECT ticketTexto FROM ventas WHERE folio = ?";

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return "";
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, folio);

                ResultSet rs =
                        ps.executeQuery();

                if (rs.next()) {

                    return rs.getString("ticketTexto");
                }
            }

        } catch (Exception e) {

            /*
             * Si la columna ticketTexto todavía no existe,
             * se intenta reconstruir el ticket con las tablas normales.
             */
        }

        return "";
    }

    private String reconstruirTicketDesdeBD(String folio) {

        StringBuilder ticket =
                new StringBuilder();

        String sqlVenta =
                "SELECT * FROM ventas WHERE folio = ?";

        String sqlDetalle =
                "SELECT d.codigoProducto, d.cantidad, d.subtotal, p.nombre " +
                        "FROM detalle_ventas d " +
                        "LEFT JOIN productos p ON d.codigoProducto = p.codigo " +
                        "WHERE d.folioVenta = ?";

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return "No se pudo conectar a la base de datos.";
            }

            try (
                    PreparedStatement psVenta = conn.prepareStatement(sqlVenta);
                    PreparedStatement psDetalle = conn.prepareStatement(sqlDetalle)
            ) {

                psVenta.setString(1, folio);

                ResultSet rsVenta =
                        psVenta.executeQuery();

                if (rsVenta.next()) {

                    ticket.append("============================================\n");
                    ticket.append("                MEGAPOS TICKET              \n");
                    ticket.append("============================================\n");

                    ticket.append("FOLIO: ")
                            .append(rsVenta.getString("folio"))
                            .append("\n");

                    ticket.append("FECHA: ")
                            .append(rsVenta.getString("fecha"))
                            .append("   HORA: ")
                            .append(rsVenta.getString("hora"))
                            .append("\n");

                    ticket.append("MÉTODO DE PAGO: ")
                            .append(rsVenta.getString("metodoPago"))
                            .append("\n");

                    ticket.append("--------------------------------------------\n");

                    ticket.append(
                            String.format(
                                    "%-5s %-8s %-14s %-8s %-8s\n",
                                    "CANT",
                                    "COD",
                                    "PRODUCTO",
                                    "P.UNIT",
                                    "SUBT"
                            )
                    );

                    ticket.append("--------------------------------------------\n");

                    psDetalle.setString(1, folio);

                    ResultSet rsDetalle =
                            psDetalle.executeQuery();

                    boolean hayDetalle =
                            false;

                    while (rsDetalle.next()) {

                        hayDetalle =
                                true;

                        String codigo =
                                rsDetalle.getString("codigoProducto");

                        String nombre =
                                rsDetalle.getString("nombre");

                        if (nombre == null) {
                            nombre = "Producto eliminado";
                        }

                        int cantidad =
                                rsDetalle.getInt("cantidad");

                        double subtotal =
                                rsDetalle.getDouble("subtotal");

                        double precioUnitario =
                                0.0;

                        if (cantidad > 0) {
                            precioUnitario = subtotal / cantidad;
                        }

                        if (nombre.length() > 13) {
                            nombre = nombre.substring(0, 13);
                        }

                        ticket.append(
                                String.format(
                                        "%-5d %-8s %-14s $%-7.2f $%-7.2f\n",
                                        cantidad,
                                        codigo,
                                        nombre,
                                        precioUnitario,
                                        subtotal
                                )
                        );
                    }

                    if (hayDetalle == false) {
                        ticket.append("No hay detalle de productos para este ticket.\n");
                    }

                    ticket.append("--------------------------------------------\n");

                    ticket.append(
                            String.format(
                                    "SUBTOTAL:                  $%.2f\n",
                                    rsVenta.getDouble("subtotal")
                            )
                    );

                    ticket.append(
                            String.format(
                                    "DESCUENTO:                 $%.2f\n",
                                    rsVenta.getDouble("descuento")
                            )
                    );

                    ticket.append(
                            String.format(
                                    "MONTO A PAGAR:             $%.2f\n",
                                    rsVenta.getDouble("total")
                            )
                    );

                    try {

                        ticket.append(
                                String.format(
                                        "MONTO RECIBIDO:            $%.2f\n",
                                        rsVenta.getDouble("montoRecibido")
                                )
                        );

                    } catch (Exception e) {

                        ticket.append("MONTO RECIBIDO:            No registrado\n");
                    }

                    ticket.append(
                            String.format(
                                    "CAMBIO:                    $%.2f\n",
                                    rsVenta.getDouble("cambio")
                            )
                    );

                    ticket.append("============================================\n");
                    ticket.append("            GRACIAS POR SU COMPRA           \n");
                    ticket.append("============================================\n");

                } else {

                    ticket.append("No se encontró el ticket con folio: ")
                            .append(folio);
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            ticket.append("Error al cargar ticket desde MySQL.\n");
            ticket.append("Detalle: ")
                    .append(e.getMessage());
        }

        return ticket.toString();
    }

    public String obtenerReportePorFecha(String fecha) {

        StringBuilder reporte =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, cambio, fecha, hora " +
                        "FROM ventas " +
                        "WHERE fecha = ? " +
                        "ORDER BY hora ASC";

        double totalDia =
                0.0;

        int contador =
                0;

        reporte.append("============================================\n");
        reporte.append("             REPORTE DE VENTAS              \n");
        reporte.append("============================================\n");
        reporte.append("FECHA: ").append(fecha).append("\n");
        reporte.append("--------------------------------------------\n");

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return "No se pudo conectar a la base de datos.";
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    contador++;

                    double total =
                            rs.getDouble("total");

                    totalDia += total;

                    reporte.append("Folio: ")
                            .append(rs.getString("folio"))
                            .append("\n");

                    reporte.append("Hora: ")
                            .append(rs.getString("hora"))
                            .append("\n");

                    reporte.append("Método: ")
                            .append(rs.getString("metodoPago"))
                            .append("\n");

                    reporte.append(
                            String.format(
                                    "Subtotal: $%.2f | Desc: $%.2f | Total: $%.2f\n",
                                    rs.getDouble("subtotal"),
                                    rs.getDouble("descuento"),
                                    total
                            )
                    );

                    reporte.append("--------------------------------------------\n");
                }
            }

            if (contador == 0) {

                reporte.append("No hay ventas registradas en esta fecha.\n");

            } else {

                reporte.append("VENTAS REGISTRADAS: ")
                        .append(contador)
                        .append("\n");

                reporte.append(
                        String.format(
                                "TOTAL DEL DÍA: $%.2f\n",
                                totalDia
                        )
                );
            }

            reporte.append("============================================\n");

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar reporte.\n");
            reporte.append(e.getMessage());
        }

        return reporte.toString();
    }

    public String obtenerCSVPorFecha(String fecha) {

        StringBuilder csv =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, cambio, fecha, hora " +
                        "FROM ventas " +
                        "WHERE fecha = ? " +
                        "ORDER BY hora ASC";

        csv.append("Folio,Fecha,Hora,MetodoPago,Subtotal,Descuento,Total,Cambio\n");

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return csv.toString();
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    csv.append(rs.getString("folio")).append(",");
                    csv.append(rs.getString("fecha")).append(",");
                    csv.append(rs.getString("hora")).append(",");
                    csv.append(rs.getString("metodoPago")).append(",");
                    csv.append(rs.getDouble("subtotal")).append(",");
                    csv.append(rs.getDouble("descuento")).append(",");
                    csv.append(rs.getDouble("total")).append(",");
                    csv.append(rs.getDouble("cambio")).append("\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return csv.toString();
    }

    public String obtenerReportePorIntervalo(
            String fechaInicio,
            String fechaFin
    ) {

        StringBuilder reporte =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, cambio, fecha, hora " +
                        "FROM ventas " +
                        "WHERE STR_TO_DATE(fecha, '%d/%m/%Y') " +
                        "BETWEEN STR_TO_DATE(?, '%d/%m/%Y') " +
                        "AND STR_TO_DATE(?, '%d/%m/%Y') " +
                        "ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') ASC, hora ASC";

        double totalIntervalo =
                0.0;

        int contador =
                0;

        reporte.append("============================================\n");
        reporte.append("          REPORTE POR INTERVALO             \n");
        reporte.append("============================================\n");
        reporte.append("INICIO: ").append(fechaInicio).append("\n");
        reporte.append("FIN:    ").append(fechaFin).append("\n");
        reporte.append("--------------------------------------------\n");

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return "No se pudo conectar a la base de datos.";
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, fechaInicio);
                ps.setString(2, fechaFin);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    contador++;

                    double total =
                            rs.getDouble("total");

                    totalIntervalo += total;

                    reporte.append("Folio: ")
                            .append(rs.getString("folio"))
                            .append("\n");

                    reporte.append("Fecha: ")
                            .append(rs.getString("fecha"))
                            .append("   Hora: ")
                            .append(rs.getString("hora"))
                            .append("\n");

                    reporte.append("Método: ")
                            .append(rs.getString("metodoPago"))
                            .append("\n");

                    reporte.append(
                            String.format(
                                    "Subtotal: $%.2f | Desc: $%.2f | Total: $%.2f\n",
                                    rs.getDouble("subtotal"),
                                    rs.getDouble("descuento"),
                                    total
                            )
                    );

                    reporte.append("--------------------------------------------\n");
                }
            }

            if (contador == 0) {

                reporte.append("No hay ventas en ese intervalo.\n");

            } else {

                reporte.append("VENTAS REGISTRADAS: ")
                        .append(contador)
                        .append("\n");

                reporte.append(
                        String.format(
                                "TOTAL INTERVALO: $%.2f\n",
                                totalIntervalo
                        )
                );
            }

            reporte.append("============================================\n");

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar reporte por intervalo.\n");
            reporte.append(e.getMessage());
        }

        return reporte.toString();
    }

    public String obtenerCSVPorIntervalo(
            String fechaInicio,
            String fechaFin
    ) {

        StringBuilder csv =
                new StringBuilder();

        String sql =
                "SELECT folio, subtotal, descuento, total, metodoPago, cambio, fecha, hora " +
                        "FROM ventas " +
                        "WHERE STR_TO_DATE(fecha, '%d/%m/%Y') " +
                        "BETWEEN STR_TO_DATE(?, '%d/%m/%Y') " +
                        "AND STR_TO_DATE(?, '%d/%m/%Y') " +
                        "ORDER BY STR_TO_DATE(fecha, '%d/%m/%Y') ASC, hora ASC";

        csv.append("Folio,Fecha,Hora,MetodoPago,Subtotal,Descuento,Total,Cambio\n");

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return csv.toString();
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, fechaInicio);
                ps.setString(2, fechaFin);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    csv.append(rs.getString("folio")).append(",");
                    csv.append(rs.getString("fecha")).append(",");
                    csv.append(rs.getString("hora")).append(",");
                    csv.append(rs.getString("metodoPago")).append(",");
                    csv.append(rs.getDouble("subtotal")).append(",");
                    csv.append(rs.getDouble("descuento")).append(",");
                    csv.append(rs.getDouble("total")).append(",");
                    csv.append(rs.getDouble("cambio")).append("\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return csv.toString();
    }

    public String obtenerReporteProductosVendidos(String fecha) {

        prepararEstructuraMinima();

        StringBuilder reporte =
                new StringBuilder();

        String sql =
                "SELECT p.codigo, p.nombre, SUM(d.cantidad) AS cantidadVendida, " +
                        "SUM(d.subtotal) AS totalVendido " +
                        "FROM detalle_ventas d " +
                        "INNER JOIN ventas v ON d.folioVenta = v.folio " +
                        "LEFT JOIN productos p ON d.codigoProducto = p.codigo " +
                        "WHERE v.fecha = ? " +
                        "GROUP BY p.codigo, p.nombre " +
                        "ORDER BY cantidadVendida DESC";

        reporte.append("============================================\n");
        reporte.append("          PRODUCTOS VENDIDOS                \n");
        reporte.append("============================================\n");
        reporte.append("FECHA: ").append(fecha).append("\n");
        reporte.append("--------------------------------------------\n");

        reporte.append(
                String.format(
                        "%-8s %-18s %-8s %-8s\n",
                        "COD",
                        "PRODUCTO",
                        "CANT",
                        "TOTAL"
                )
        );

        reporte.append("--------------------------------------------\n");

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return "No se pudo conectar a la base de datos.";
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                boolean hayDatos =
                        false;

                while (rs.next()) {

                    hayDatos =
                            true;

                    String codigo =
                            rs.getString("codigo");

                    String nombre =
                            rs.getString("nombre");

                    if (codigo == null) {
                        codigo = "N/A";
                    }

                    if (nombre == null) {
                        nombre = "Producto eliminado";
                    }

                    if (nombre.length() > 16) {
                        nombre = nombre.substring(0, 16);
                    }

                    reporte.append(
                            String.format(
                                    "%-8s %-18s %-8d $%-8.2f\n",
                                    codigo,
                                    nombre,
                                    rs.getInt("cantidadVendida"),
                                    rs.getDouble("totalVendido")
                            )
                    );
                }

                if (hayDatos == false) {
                    reporte.append("No hay productos vendidos en esta fecha.\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar reporte de productos vendidos.\n");
            reporte.append(e.getMessage());
        }

        reporte.append("============================================\n");

        return reporte.toString();
    }

    public String obtenerCSVProductosVendidos(String fecha) {

        prepararEstructuraMinima();

        StringBuilder csv =
                new StringBuilder();

        String sql =
                "SELECT p.codigo, p.nombre, SUM(d.cantidad) AS cantidadVendida, " +
                        "SUM(d.subtotal) AS totalVendido " +
                        "FROM detalle_ventas d " +
                        "INNER JOIN ventas v ON d.folioVenta = v.folio " +
                        "LEFT JOIN productos p ON d.codigoProducto = p.codigo " +
                        "WHERE v.fecha = ? " +
                        "GROUP BY p.codigo, p.nombre " +
                        "ORDER BY cantidadVendida DESC";

        csv.append("Codigo,Producto,CantidadVendida,TotalVendido\n");

        try (
                Connection conn = ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return csv.toString();
            }

            try (
                    PreparedStatement ps = conn.prepareStatement(sql)
            ) {

                ps.setString(1, fecha);

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    String codigo =
                            rs.getString("codigo");

                    String nombre =
                            rs.getString("nombre");

                    if (codigo == null) {
                        codigo = "N/A";
                    }

                    if (nombre == null) {
                        nombre = "Producto eliminado";
                    }

                    csv.append(codigo).append(",");
                    csv.append(nombre).append(",");
                    csv.append(rs.getInt("cantidadVendida")).append(",");
                    csv.append(rs.getDouble("totalVendido")).append("\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return csv.toString();
    }
}