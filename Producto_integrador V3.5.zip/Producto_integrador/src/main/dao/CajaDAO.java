package main.dao;

import main.util.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CajaDAO {

    private void asegurarTabla(Connection conn) {

        String sql =
                "CREATE TABLE IF NOT EXISTS cierres_caja (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "rol VARCHAR(50) NOT NULL, " +
                        "fecha VARCHAR(20) NOT NULL, " +
                        "hora VARCHAR(20) NOT NULL, " +
                        "cajaInicial DOUBLE NOT NULL, " +
                        "totalVentas DOUBLE NOT NULL, " +
                        "ventasEfectivo DOUBLE NOT NULL, " +
                        "ventasTarjeta DOUBLE NOT NULL, " +
                        "totalFinalCaja DOUBLE NOT NULL, " +
                        "cantidadTickets INT NOT NULL, " +
                        "folios TEXT NOT NULL" +
                        ")";

        try (
                Statement st =
                        conn.createStatement()
        ) {

            st.executeUpdate(sql);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private String obtenerHoraUltimoCierre(
            Connection conn,
            String fecha
    ) {

        String sql =
                "SELECT hora " +
                        "FROM cierres_caja " +
                        "WHERE fecha = ? " +
                        "ORDER BY id DESC " +
                        "LIMIT 1";

        try (
                PreparedStatement ps =
                        conn.prepareStatement(sql)
        ) {

            ps.setString(1, fecha);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                return rs.getString("hora");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }

    public String generarCierreCaja(
            String rol,
            double cajaInicial
    ) {

        String fecha =
                LocalDate.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "dd/MM/yyyy"
                                )
                        );

        String hora =
                LocalTime.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "HH:mm:ss"
                                )
                        );

        StringBuilder folios =
                new StringBuilder();

        StringBuilder reporte =
                new StringBuilder();

        double totalVentas =
                0.0;

        double ventasEfectivo =
                0.0;

        double ventasTarjeta =
                0.0;

        int cantidadTickets =
                0;

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                return "No se pudo conectar a la base de datos.";
            }

            asegurarTabla(conn);

            String horaUltimoCierre =
                    obtenerHoraUltimoCierre(
                            conn,
                            fecha
                    );

            String sqlVentas;

            if (horaUltimoCierre == null) {

                sqlVentas =
                        "SELECT folio, total, metodoPago, hora " +
                                "FROM ventas " +
                                "WHERE fecha = ? " +
                                "ORDER BY hora ASC";

            } else {

                sqlVentas =
                        "SELECT folio, total, metodoPago, hora " +
                                "FROM ventas " +
                                "WHERE fecha = ? AND hora > ? " +
                                "ORDER BY hora ASC";
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sqlVentas)
            ) {

                ps.setString(1, fecha);

                if (horaUltimoCierre != null) {

                    ps.setString(2, horaUltimoCierre);
                }

                ResultSet rs =
                        ps.executeQuery();

                while (rs.next()) {

                    String folio =
                            rs.getString("folio");

                    double total =
                            rs.getDouble("total");

                    String metodo =
                            rs.getString("metodoPago");

                    String horaVenta =
                            rs.getString("hora");

                    cantidadTickets++;

                    totalVentas += total;

                    if (metodo != null
                            && metodo.equalsIgnoreCase("TARJETA")) {

                        ventasTarjeta += total;

                    } else {

                        ventasEfectivo += total;
                    }

                    folios.append(folio)
                            .append(" | ")
                            .append(horaVenta)
                            .append(" | ")
                            .append(metodo)
                            .append(" | $")
                            .append(String.format("%.2f", total))
                            .append("\n");
                }
            }

            double totalFinalCaja =
                    cajaInicial + ventasEfectivo;

            guardarCierre(
                    conn,
                    rol,
                    fecha,
                    hora,
                    cajaInicial,
                    totalVentas,
                    ventasEfectivo,
                    ventasTarjeta,
                    totalFinalCaja,
                    cantidadTickets,
                    folios.toString()
            );

            reporte.append("============================================\n");
            reporte.append("                CIERRE DE CAJA              \n");
            reporte.append("============================================\n");
            reporte.append("ROL: ").append(rol).append("\n");
            reporte.append("FECHA: ").append(fecha).append("\n");
            reporte.append("HORA DE CIERRE: ").append(hora).append("\n");

            if (horaUltimoCierre == null) {

                reporte.append("PERIODO: Inicio del día a ")
                        .append(hora)
                        .append("\n");

            } else {

                reporte.append("PERIODO: ")
                        .append(horaUltimoCierre)
                        .append(" a ")
                        .append(hora)
                        .append("\n");
            }

            reporte.append("--------------------------------------------\n");
            reporte.append(String.format("CAJA INICIAL:       $%.2f\n", cajaInicial));
            reporte.append(String.format("VENTAS EFECTIVO:    $%.2f\n", ventasEfectivo));
            reporte.append(String.format("VENTAS TARJETA:     $%.2f\n", ventasTarjeta));
            reporte.append(String.format("TOTAL VENTAS:       $%.2f\n", totalVentas));
            reporte.append(String.format("TOTAL FINAL CAJA:   $%.2f\n", totalFinalCaja));
            reporte.append("TICKETS DEL PERIODO: ")
                    .append(cantidadTickets)
                    .append("\n");
            reporte.append("--------------------------------------------\n");
            reporte.append("TICKETS INCLUIDOS EN ESTE CIERRE:\n");

            if (folios.length() == 0) {

                reporte.append("No hubo tickets nuevos desde el último cierre.\n");

            } else {

                reporte.append(folios);
            }

            reporte.append("============================================\n");

        } catch (Exception e) {

            e.printStackTrace();

            reporte.append("Error al generar cierre de caja.");
        }

        return reporte.toString();
    }

    private void guardarCierre(
            Connection conn,
            String rol,
            String fecha,
            String hora,
            double cajaInicial,
            double totalVentas,
            double ventasEfectivo,
            double ventasTarjeta,
            double totalFinalCaja,
            int cantidadTickets,
            String folios
    ) {

        String sql =
                "INSERT INTO cierres_caja " +
                        "(rol, fecha, hora, cajaInicial, totalVentas, ventasEfectivo, ventasTarjeta, totalFinalCaja, cantidadTickets, folios) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (
                PreparedStatement ps =
                        conn.prepareStatement(sql)
        ) {

            ps.setString(1, rol);
            ps.setString(2, fecha);
            ps.setString(3, hora);
            ps.setDouble(4, cajaInicial);
            ps.setDouble(5, totalVentas);
            ps.setDouble(6, ventasEfectivo);
            ps.setDouble(7, ventasTarjeta);
            ps.setDouble(8, totalFinalCaja);
            ps.setInt(9, cantidadTickets);
            ps.setString(10, folios);

            ps.executeUpdate();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}