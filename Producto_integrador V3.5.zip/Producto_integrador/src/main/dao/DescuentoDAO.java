package main.dao;

import main.util.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.table.DefaultTableModel;

public class DescuentoDAO {

    public void asegurarTablaYDatosBase() {

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return;
            }

            String sqlTabla =
                    "CREATE TABLE IF NOT EXISTS descuentos (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "nombre VARCHAR(100) NOT NULL, " +
                            "ambito VARCHAR(30) NOT NULL, " +
                            "tipo VARCHAR(30) NOT NULL, " +
                            "valor DOUBLE NOT NULL DEFAULT 0, " +
                            "activo TINYINT(1) NOT NULL DEFAULT 1" +
                            ")";

            try (
                    Statement st =
                            conn.createStatement()
            ) {

                st.executeUpdate(sqlTabla);
                st.executeUpdate("UPDATE productos SET stockMinimo = 10");
            }

            insertarSiNoExiste(
                    conn,
                    "Descuento 10%",
                    "PRODUCTO",
                    "PORCENTAJE",
                    10
            );

            insertarSiNoExiste(
                    conn,
                    "Descuento 15%",
                    "PRODUCTO",
                    "PORCENTAJE",
                    15
            );

            insertarSiNoExiste(
                    conn,
                    "Descuento 20%",
                    "PRODUCTO",
                    "PORCENTAJE",
                    20
            );

            insertarSiNoExiste(
                    conn,
                    "Promoción 2x1",
                    "PRODUCTO",
                    "DOS_POR_UNO",
                    0
            );

            insertarSiNoExiste(
                    conn,
                    "Promoción 3x2",
                    "PRODUCTO",
                    "TRES_POR_DOS",
                    0
            );

            insertarSiNoExiste(
                    conn,
                    "Proveedor 5%",
                    "PROVEEDOR",
                    "PORCENTAJE",
                    5
            );

            insertarSiNoExiste(
                    conn,
                    "Proveedor 10%",
                    "PROVEEDOR",
                    "PORCENTAJE",
                    10
            );

            insertarSiNoExiste(
                    conn,
                    "Mayoreo $50",
                    "PRODUCTO",
                    "MONTO_FIJO",
                    50
            );

            insertarSiNoExiste(
                    conn,
                    "Liquidación 30%",
                    "PRODUCTO",
                    "PORCENTAJE",
                    30
            );

            insertarSiNoExiste(
                    conn,
                    "Cliente frecuente 5%",
                    "PRODUCTO",
                    "PORCENTAJE",
                    5
            );

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void insertarSiNoExiste(
            Connection conn,
            String nombre,
            String ambito,
            String tipo,
            double valor
    ) {

        String sqlBuscar =
                "SELECT id FROM descuentos WHERE nombre = ?";

        String sqlInsertar =
                "INSERT INTO descuentos " +
                        "(nombre, ambito, tipo, valor, activo) " +
                        "VALUES (?, ?, ?, ?, 1)";

        try (
                PreparedStatement psBuscar =
                        conn.prepareStatement(sqlBuscar);

                PreparedStatement psInsertar =
                        conn.prepareStatement(sqlInsertar)
        ) {

            psBuscar.setString(1, nombre);

            ResultSet rs =
                    psBuscar.executeQuery();

            if (rs.next()) {

                return;
            }

            psInsertar.setString(1, nombre);
            psInsertar.setString(2, ambito);
            psInsertar.setString(3, tipo);
            psInsertar.setDouble(4, valor);

            psInsertar.executeUpdate();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public DefaultTableModel obtenerModeloDescuentos() {

        DefaultTableModel modelo =
                new DefaultTableModel(
                        new String[]{
                                "ID",
                                "Nombre",
                                "Ámbito",
                                "Tipo",
                                "Valor",
                                "Activo"
                        },
                        0
                );

        String sql =
                "SELECT id, nombre, ambito, tipo, valor, activo " +
                        "FROM descuentos " +
                        "ORDER BY id ASC";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return modelo;
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql);

                    ResultSet rs =
                            ps.executeQuery()
            ) {

                while (rs.next()) {

                    Object[] fila = {
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("ambito"),
                            rs.getString("tipo"),
                            rs.getDouble("valor"),
                            rs.getInt("activo") == 1 ? "Sí" : "No"
                    };

                    modelo.addRow(fila);
                }
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return modelo;
    }

    public boolean agregarDescuento(
            String nombre,
            String ambito,
            String tipo,
            double valor,
            boolean activo
    ) {

        String sql =
                "INSERT INTO descuentos " +
                        "(nombre, ambito, tipo, valor, activo) " +
                        "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, nombre);
                ps.setString(2, ambito);
                ps.setString(3, tipo);
                ps.setDouble(4, valor);
                ps.setInt(5, activo ? 1 : 0);

                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public boolean actualizarDescuento(
            int id,
            String nombre,
            String ambito,
            String tipo,
            double valor,
            boolean activo
    ) {

        String sql =
                "UPDATE descuentos " +
                        "SET nombre = ?, ambito = ?, tipo = ?, valor = ?, activo = ? " +
                        "WHERE id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, nombre);
                ps.setString(2, ambito);
                ps.setString(3, tipo);
                ps.setDouble(4, valor);
                ps.setInt(5, activo ? 1 : 0);
                ps.setInt(6, id);

                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public boolean eliminarDescuento(int id) {

        String sql =
                "DELETE FROM descuentos WHERE id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setInt(1, id);

                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }
}