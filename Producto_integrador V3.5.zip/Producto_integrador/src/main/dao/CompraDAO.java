package main.dao;

import main.util.ConexionBD;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class CompraDAO {

    private void asegurarTablaYColumnas(Connection conn) {

        try {

            String sqlCrear =
                    "CREATE TABLE IF NOT EXISTS detalle_compras (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "codigoProducto VARCHAR(50) NOT NULL, " +
                            "cantidad INT NOT NULL" +
                            ")";

            try (
                    Statement st =
                            conn.createStatement()
            ) {

                st.executeUpdate(sqlCrear);
            }

            agregarColumnaSiNoExiste(
                    conn,
                    "precioCompra",
                    "DOUBLE NOT NULL DEFAULT 0"
            );

            agregarColumnaSiNoExiste(
                    conn,
                    "proveedor",
                    "VARCHAR(100) NOT NULL DEFAULT 'Sin proveedor'"
            );

            agregarColumnaSiNoExiste(
                    conn,
                    "fecha",
                    "VARCHAR(20) NOT NULL DEFAULT ''"
            );

            agregarColumnaSiNoExiste(
                    conn,
                    "hora",
                    "VARCHAR(20) NOT NULL DEFAULT ''"
            );

            agregarColumnaSiNoExiste(
                    conn,
                    "cancelada",
                    "TINYINT(1) NOT NULL DEFAULT 0"
            );

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void agregarColumnaSiNoExiste(
            Connection conn,
            String columna,
            String definicion
    ) {

        try {

            DatabaseMetaData meta =
                    conn.getMetaData();

            ResultSet rs =
                    meta.getColumns(
                            null,
                            null,
                            "detalle_compras",
                            columna
                    );

            if (rs.next()) {

                return;
            }

            String sql =
                    "ALTER TABLE detalle_compras ADD COLUMN "
                            + columna
                            + " "
                            + definicion;

            try (
                    Statement st =
                            conn.createStatement()
            ) {

                st.executeUpdate(sql);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public boolean registrarEntradaMercancia(
            String codigoProducto,
            int cantidad,
            double precioCompra,
            String proveedor
    ) {

        String fecha =
                LocalDate.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "dd/MM/yyyy"
                                )
                        );

        String hora =
                LocalTime.now()
                        .format(
                                DateTimeFormatter.ofPattern(
                                        "HH:mm:ss"
                                )
                        );

        String sqlInsertCompra =
                "INSERT INTO detalle_compras " +
                        "(codigoProducto, cantidad, precioCompra, proveedor, fecha, hora, cancelada) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";

        String sqlActualizarProducto =
                "UPDATE productos " +
                        "SET stock = stock + ?, precioCompra = ? " +
                        "WHERE codigo = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            asegurarTablaYColumnas(conn);

            conn.setAutoCommit(false);

            try (
                    PreparedStatement psCompra =
                            conn.prepareStatement(sqlInsertCompra);

                    PreparedStatement psProducto =
                            conn.prepareStatement(sqlActualizarProducto)
            ) {

                psCompra.setString(1, codigoProducto);
                psCompra.setInt(2, cantidad);
                psCompra.setDouble(3, precioCompra);
                psCompra.setString(4, proveedor);
                psCompra.setString(5, fecha);
                psCompra.setString(6, hora);
                psCompra.setInt(7, 0);

                psCompra.executeUpdate();

                psProducto.setInt(1, cantidad);
                psProducto.setDouble(2, precioCompra);
                psProducto.setString(3, codigoProducto);

                int filasActualizadas =
                        psProducto.executeUpdate();

                if (filasActualizadas == 0) {

                    conn.rollback();

                    return false;
                }

                conn.commit();

                return true;

            } catch (Exception e) {

                conn.rollback();

                e.printStackTrace();

                return false;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public boolean compraExiste(int idCompra) {

        String sql =
                "SELECT id FROM detalle_compras WHERE id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            asegurarTablaYColumnas(conn);

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setInt(1, idCompra);

                ResultSet rs =
                        ps.executeQuery();

                return rs.next();
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

    public String obtenerHistorialCompras() {

        StringBuilder sb =
                new StringBuilder();

        String sql =
                "SELECT dc.id, dc.codigoProducto, p.nombre, dc.cantidad, " +
                        "dc.precioCompra, dc.proveedor, dc.fecha, dc.hora, dc.cancelada " +
                        "FROM detalle_compras dc " +
                        "INNER JOIN productos p ON dc.codigoProducto = p.codigo " +
                        "ORDER BY dc.id DESC";

        sb.append("============================================\n");
        sb.append("        HISTORIAL ENTRADAS PROVEEDORES       \n");
        sb.append("============================================\n");

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                sb.append("No se pudo conectar a la base de datos.\n");

                return sb.toString();
            }

            asegurarTablaYColumnas(conn);

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql);

                    ResultSet rs =
                            ps.executeQuery()
            ) {

                boolean hayDatos =
                        false;

                while (rs.next()) {

                    hayDatos =
                            true;

                    String estado;

                    if (rs.getInt("cancelada") == 1) {

                        estado =
                                "CANCELADA";

                    } else {

                        estado =
                                "ACTIVA";
                    }

                    double total =
                            rs.getInt("cantidad")
                                    * rs.getDouble("precioCompra");

                    sb.append("ID ENTRADA: ")
                            .append(rs.getInt("id"))
                            .append("\n");

                    sb.append("Producto: ")
                            .append(rs.getString("codigoProducto"))
                            .append(" - ")
                            .append(rs.getString("nombre"))
                            .append("\n");

                    sb.append("Proveedor: ")
                            .append(rs.getString("proveedor"))
                            .append("\n");

                    sb.append("Cantidad: ")
                            .append(rs.getInt("cantidad"))
                            .append("\n");

                    sb.append(
                            String.format(
                                    "Precio compra: $%.2f\n",
                                    rs.getDouble("precioCompra")
                            )
                    );

                    sb.append(
                            String.format(
                                    "Total entrada: $%.2f\n",
                                    total
                            )
                    );

                    sb.append("Estado: ")
                            .append(estado)
                            .append("\n");

                    sb.append("Fecha: ")
                            .append(rs.getString("fecha"))
                            .append("  Hora: ")
                            .append(rs.getString("hora"))
                            .append("\n");

                    sb.append("--------------------------------------------\n");
                }

                if (hayDatos == false) {

                    sb.append("No hay entradas registradas.\n");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            sb.append("Error al cargar historial de proveedores.\n");
        }

        return sb.toString();
    }

    public String obtenerResumenCompras() {

        return obtenerHistorialCompras();
    }

    public String obtenerDetalleCancelacion(int idCompra) {

        StringBuilder sb =
                new StringBuilder();

        String sql =
                "SELECT dc.id, dc.codigoProducto, p.nombre, dc.cantidad, " +
                        "dc.precioCompra, dc.proveedor, dc.fecha, dc.hora, dc.cancelada " +
                        "FROM detalle_compras dc " +
                        "INNER JOIN productos p ON dc.codigoProducto = p.codigo " +
                        "WHERE dc.id = ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {

                return "No se pudo conectar a la base de datos.";
            }

            asegurarTablaYColumnas(conn);

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setInt(1, idCompra);

                ResultSet rs =
                        ps.executeQuery();

                if (rs.next()) {

                    String estado;

                    if (rs.getInt("cancelada") == 1) {

                        estado =
                                "CANCELADA";

                    } else {

                        estado =
                                "ACTIVA";
                    }

                    double total =
                            rs.getInt("cantidad")
                                    * rs.getDouble("precioCompra");

                    sb.append("ID ENTRADA: ")
                            .append(rs.getInt("id"))
                            .append("\n");

                    sb.append("Producto: ")
                            .append(rs.getString("codigoProducto"))
                            .append(" - ")
                            .append(rs.getString("nombre"))
                            .append("\n");

                    sb.append("Proveedor: ")
                            .append(rs.getString("proveedor"))
                            .append("\n");

                    sb.append("Cantidad: ")
                            .append(rs.getInt("cantidad"))
                            .append("\n");

                    sb.append(
                            String.format(
                                    "Precio compra: $%.2f\n",
                                    rs.getDouble("precioCompra")
                            )
                    );

                    sb.append(
                            String.format(
                                    "Total entrada: $%.2f\n",
                                    total
                            )
                    );

                    sb.append("Estado: ")
                            .append(estado)
                            .append("\n");

                    sb.append("Fecha: ")
                            .append(rs.getString("fecha"))
                            .append("  Hora: ")
                            .append(rs.getString("hora"))
                            .append("\n");

                } else {

                    sb.append("No se encontró la entrada con ID ")
                            .append(idCompra)
                            .append(".");
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

            sb.append("Error al obtener detalle de cancelación.");
        }

        return sb.toString();
    }

    public boolean cancelarCompra(int idCompra) {

        return cancelarEntradaMercancia(idCompra);
    }

    public boolean cancelarEntradaMercancia(int idCompra) {

        String sqlBuscar =
                "SELECT codigoProducto, cantidad, cancelada " +
                        "FROM detalle_compras " +
                        "WHERE id = ?";

        String sqlCancelar =
                "UPDATE detalle_compras " +
                        "SET cancelada = 1 " +
                        "WHERE id = ?";

        String sqlRestarStock =
                "UPDATE productos " +
                        "SET stock = stock - ? " +
                        "WHERE codigo = ? AND stock >= ?";

        try (
                Connection conn =
                        ConexionBD.getConexion()
        ) {

            if (conn == null) {
                return false;
            }

            asegurarTablaYColumnas(conn);

            conn.setAutoCommit(false);

            try (
                    PreparedStatement psBuscar =
                            conn.prepareStatement(sqlBuscar);

                    PreparedStatement psCancelar =
                            conn.prepareStatement(sqlCancelar);

                    PreparedStatement psStock =
                            conn.prepareStatement(sqlRestarStock)
            ) {

                psBuscar.setInt(1, idCompra);

                ResultSet rs =
                        psBuscar.executeQuery();

                if (rs.next() == false) {

                    conn.rollback();

                    return false;
                }

                String codigoProducto =
                        rs.getString("codigoProducto");

                int cantidad =
                        rs.getInt("cantidad");

                int cancelada =
                        rs.getInt("cancelada");

                if (cancelada == 1) {

                    conn.rollback();

                    return false;
                }

                psStock.setInt(1, cantidad);
                psStock.setString(2, codigoProducto);
                psStock.setInt(3, cantidad);

                int stockActualizado =
                        psStock.executeUpdate();

                if (stockActualizado == 0) {

                    conn.rollback();

                    return false;
                }

                psCancelar.setInt(1, idCompra);

                psCancelar.executeUpdate();

                conn.commit();

                return true;

            } catch (Exception e) {

                conn.rollback();

                e.printStackTrace();

                return false;
            }

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }
}