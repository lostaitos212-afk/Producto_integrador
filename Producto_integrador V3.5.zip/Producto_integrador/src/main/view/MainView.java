package main.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class MainView extends JFrame {

    public CardLayout cardLayout;
    public JPanel contentPanel;

    // Datos de sesión / caja
    public String rolOperador = "CAJERO";
    public double cajaInicial = 1000.0;

    // --- MÓDULO VENTAS ---
    public JTextField txtBuscarProd = new JTextField();
    public JComboBox<String> cmbCategoriaVentas = new JComboBox<>();
    public JTextField txtCantidadVenta = new JTextField("1");

    public JButton btnCantMenosVenta =
            new BotonPildora("-", new Color(239, 68, 68), Color.WHITE);

    public JButton btnCantMasVenta =
            new BotonPildora("+", new Color(16, 185, 129), Color.WHITE);

    public JButton btnAgregarCarrito =
            new BotonPildora("AGREGAR", new Color(59, 130, 246), Color.WHITE);

    public DefaultTableModel modeloCarrito =
            new DefaultTableModel(
                    new String[]{"Código", "Cant", "Producto", "Precio", "Subtotal"},
                    0
            );

    public JTable tablaCarrito = new JTable(modeloCarrito);

    public JLabel lblTotal = new JLabel("$0.00", SwingConstants.RIGHT);
    public JTextField txtEfectivo = new JTextField("0");

    public JComboBox<String> cmbMetodoPago =
            new JComboBox<>(new String[]{"EFECTIVO", "TARJETA"});

    public JTextField txtDescuento = new JTextField("0");
    public JLabel lblCambio = new JLabel("$0.00", SwingConstants.RIGHT);

    public JButton btnCobrar =
            new BotonPildora("PAGAR Y GENERAR TICKET", new Color(16, 185, 129), Color.WHITE);

    public JButton btnEliminarProducto =
            new BotonPildora("🗑", new Color(239, 68, 68), Color.WHITE);

    public JButton btnQuitarUno =
            new BotonPildora("-", new Color(245, 158, 11), Color.WHITE);

    public JButton btnVaciarCarrito =
            new BotonPildora("VACIAR", new Color(100, 116, 139), Color.WHITE);

    public JPanel pnlGridProductos;

    // --- MÓDULO INVENTARIO ---
    public JTextField txtBuscarInventario = new JTextField();
    public JComboBox<String> cmbCategoriaInventario = new JComboBox<>();

    public DefaultTableModel modeloInventario =
            new DefaultTableModel(
                    new String[]{"ID", "Nombre", "Categoría", "Precio Venta", "Stock", "Estado"},
                    0
            );

    public JTable tablaInventario = new JTable(modeloInventario);

    public JTextField txtInvId = new JTextField();
    public JTextField txtInvNombre = new JTextField();
    public JTextField txtInvCategoria = new JTextField();
    public JTextField txtInvPrecio = new JTextField();
    public JTextField txtInvStock = new JTextField();
    public JTextField txtInvRutaImagen = new JTextField();

    public JButton btnInvStockMenos =
            new BotonPildora("-", new Color(239, 68, 68), Color.WHITE);

    public JButton btnInvStockMas =
            new BotonPildora("+", new Color(16, 185, 129), Color.WHITE);

    public JButton btnSeleccionarImagen =
            new BotonPildora("SELECCIONAR IMAGEN", new Color(59, 130, 246), Color.WHITE);

    public JButton btnInvAgregar =
            new BotonPildora("NUEVO", new Color(16, 185, 129), Color.WHITE);

    public JButton btnInvModificar =
            new BotonPildora("GUARDAR", new Color(59, 130, 246), Color.WHITE);

    public JButton btnInvEliminar =
            new BotonPildora("ELIMINAR", new Color(239, 68, 68), Color.WHITE);

    // --- MÓDULO PROVEEDORES ---
    public JTextField txtCompraCodigo = new JTextField();
    public JTextField txtCompraProveedor = new JTextField();
    public JTextField txtCompraCantidad = new JTextField("1");
    public JTextField txtCompraPrecio = new JTextField();
    public JTextField txtCompraIdCancelar = new JTextField();

    public JButton btnCompraMenos =
            new BotonPildora("-", new Color(239, 68, 68), Color.WHITE);

    public JButton btnCompraMas =
            new BotonPildora("+", new Color(16, 185, 129), Color.WHITE);

    public JButton btnRegistrarCompra =
            new BotonPildora("REGISTRAR ENTRADA", new Color(16, 185, 129), Color.WHITE);

    public JButton btnVerCompras =
            new BotonPildora("HISTORIAL PROVEEDORES", new Color(59, 130, 246), Color.WHITE);

    public JButton btnCancelarCompra =
            new BotonPildora("CANCELAR ENTRADA", new Color(239, 68, 68), Color.WHITE);

    public JTextArea txtResultadoCompra = new JTextArea();

    // --- MÓDULO DEVOLUCIONES ---
    public JTextField txtDevFolio = new JTextField();
    public JTextField txtDevCodigo = new JTextField();
    public JTextField txtDevCantidad = new JTextField("1");
    public JTextField txtDevMotivo = new JTextField();

    public JButton btnDevCantidadMenos =
            new BotonPildora("-", new Color(239, 68, 68), Color.WHITE);

    public JButton btnDevCantidadMas =
            new BotonPildora("+", new Color(16, 185, 129), Color.WHITE);

    public JButton btnRegistrarDevolucion =
            new BotonPildora("REGISTRAR DEVOLUCIÓN", new Color(16, 185, 129), Color.WHITE);

    public JButton btnVerDevoluciones =
            new BotonPildora("VER HISTORIAL", new Color(59, 130, 246), Color.WHITE);

    public JTextArea txtResultadoDevolucion = new JTextArea();

    // --- MÓDULO AUDITORÍA TICKETS ---
    public JComboBox<String> cmbTicketsGenerados = new JComboBox<>();
    public JTextArea txtVisorTicket = new JTextArea();

    public JButton btnVerTicket =
            new BotonPildora("VISUALIZAR TICKET", new Color(59, 130, 246), Color.WHITE);

    // --- MÓDULO REPORTES ---
    public JTextField txtFechaReporte = new JTextField();
    public JTextField txtFechaInicioReporte = new JTextField();
    public JTextField txtFechaFinReporte = new JTextField();

    public JButton btnReporteFecha =
            new BotonPildora("REPORTE POR FECHA", new Color(16, 185, 129), Color.WHITE);

    public JButton btnExportarReporte =
            new BotonPildora("EXPORTAR FECHA", new Color(245, 158, 11), Color.WHITE);

    public JButton btnReporteIntervalo =
            new BotonPildora("REPORTE INTERVALO", new Color(16, 185, 129), Color.WHITE);

    public JButton btnExportarIntervalo =
            new BotonPildora("EXPORTAR INTERVALO", new Color(245, 158, 11), Color.WHITE);

    public JButton btnReporteProductosVendidos =
            new BotonPildora("PRODUCTOS VENDIDOS", new Color(16, 185, 129), Color.WHITE);

    public JButton btnExportarProductosVendidos =
            new BotonPildora("EXPORTAR PRODUCTOS", new Color(245, 158, 11), Color.WHITE);

    public JButton btnReporteStockBajo =
            new BotonPildora("STOCK BAJO", new Color(239, 68, 68), Color.WHITE);

    // --- MÓDULO DESCUENTOS ---
    public DefaultTableModel modeloDescuentos =
            new DefaultTableModel(
                    new String[]{"ID", "Nombre", "Ámbito", "Tipo", "Valor", "Activo"},
                    0
            );

    public JTable tablaDescuentos = new JTable(modeloDescuentos);

    public JTextField txtDescId = new JTextField();
    public JTextField txtDescNombre = new JTextField();

    public JComboBox<String> cmbDescAmbito =
            new JComboBox<>(new String[]{"PRODUCTO", "PROVEEDOR"});

    public JComboBox<String> cmbDescTipo =
            new JComboBox<>(
                    new String[]{
                            "PORCENTAJE",
                            "MONTO_FIJO",
                            "DOS_POR_UNO",
                            "TRES_POR_DOS"
                    }
            );

    public JTextField txtDescValor = new JTextField("0");
    public JCheckBox chkDescActivo = new JCheckBox("Activo", true);

    public JButton btnDescNuevo =
            new BotonPildora("NUEVO", new Color(100, 116, 139), Color.WHITE);

    public JButton btnDescGuardar =
            new BotonPildora("GUARDAR", new Color(16, 185, 129), Color.WHITE);

    public JButton btnDescActualizar =
            new BotonPildora("ACTUALIZAR", new Color(59, 130, 246), Color.WHITE);

    public JButton btnDescEliminar =
            new BotonPildora("ELIMINAR", new Color(239, 68, 68), Color.WHITE);

    public JButton btnDescRecargar =
            new BotonPildora("RECARGAR", new Color(245, 158, 11), Color.WHITE);

    // Sidebar
    public JButton btnNavVentas;
    public JButton btnNavInventario;
    public JButton btnNavCompras;
    public JButton btnNavDescuentos;
    public JButton btnNavDevoluciones;
    public JButton btnNavAuditoria;
    public JButton btnNavReportes;
    public JButton btnCerrarCaja;

    // Colores
    public final Color COLOR_BG = new Color(8, 10, 18);
    public final Color COLOR_CARD = new Color(15, 23, 42);
    public final Color COLOR_PANEL = new Color(11, 18, 32);
    public final Color COLOR_INPUT = new Color(30, 41, 59);
    public final Color COLOR_BORDER = new Color(51, 65, 85);
    public final Color COLOR_TEXT_MUTED = new Color(148, 163, 184);
    public final Color COLOR_TEXT_LIGHT = new Color(248, 250, 252);
    public final Color COLOR_GREEN = new Color(16, 185, 129);
    public final Color COLOR_BLUE = new Color(59, 130, 246);
    public final Color COLOR_RED = new Color(239, 68, 68);
    public final Color COLOR_ORANGE = new Color(245, 158, 11);

    public MainView() {

        this("ADMIN", 100000.0);
    }

    public MainView(String rolOperador, double cajaInicial) {

        this.rolOperador = rolOperador;
        this.cajaInicial = cajaInicial;

        setTitle("MEGAPOS - Enterprise v5.3");
        setSize(1366, 768);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(COLOR_BG);

        ensamblarInterfaz();
    }

    private void ensamblarInterfaz() {

        add(crearSidebar(), BorderLayout.WEST);

        JPanel centroPanel = new JPanel(new BorderLayout());
        centroPanel.setBackground(COLOR_BG);

        JPanel topbar = new JPanel(new BorderLayout());
        topbar.setPreferredSize(new Dimension(0, 60));
        topbar.setBackground(COLOR_CARD);

        topbar.setBorder(
                BorderFactory.createMatteBorder(
                        0,
                        0,
                        1,
                        0,
                        new Color(30, 41, 59)
                )
        );

        JLabel lblUser =
                new JLabel(
                        " Operador: "
                                + rolOperador
                                + "   |   Caja inicial: $"
                                + String.format("%.2f", cajaInicial)
                );

        lblUser.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblUser.setForeground(COLOR_TEXT_LIGHT);
        lblUser.setBorder(new EmptyBorder(0, 20, 0, 0));

        topbar.add(lblUser, BorderLayout.WEST);
        centroPanel.add(topbar, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(COLOR_BG);

        contentPanel.add(construirPanelVentas(), "VENTAS");
        contentPanel.add(construirPanelInventario(), "INVENTARIO");

        if (rolOperador.equalsIgnoreCase("ADMIN")) {

            contentPanel.add(construirPanelCompras(), "COMPRAS");
            contentPanel.add(construirPanelDescuentos(), "DESCUENTOS");
        }

        contentPanel.add(construirPanelDevoluciones(), "DEVOLUCIONES");
        contentPanel.add(construirPanelAuditoriaTickets(), "AUDITORIA");
        contentPanel.add(construirPanelReportes(), "REPORTES");

        centroPanel.add(contentPanel, BorderLayout.CENTER);
        add(centroPanel, BorderLayout.CENTER);

        cardLayout.show(contentPanel, "VENTAS");
    }

    private JPanel crearSidebar() {

        JPanel s = new JPanel();

        s.setPreferredSize(new Dimension(220, 0));
        s.setBackground(COLOR_CARD);
        s.setLayout(new BoxLayout(s, BoxLayout.Y_AXIS));
        s.setBorder(new EmptyBorder(25, 15, 25, 15));

        JLabel lblLogo =
                new JLabel("<html><b style='color:#FFF; font-size:18px;'>MEGA</b><b style='color:#10B981; font-size:18px;'>POS</b></html>");

        s.add(lblLogo);
        s.add(Box.createRigidArea(new Dimension(0, 40)));

        btnNavVentas =
                new BotonPildora("  Ventas", COLOR_GREEN, Color.WHITE);

        btnNavInventario =
                new BotonPildora("  Inventario", COLOR_CARD, COLOR_TEXT_MUTED);

        btnNavCompras =
                new BotonPildora("  Proveedores", COLOR_CARD, COLOR_TEXT_MUTED);

        btnNavDescuentos =
                new BotonPildora("  Descuentos", COLOR_CARD, COLOR_TEXT_MUTED);

        btnNavDevoluciones =
                new BotonPildora("  Devoluciones", COLOR_CARD, COLOR_TEXT_MUTED);

        btnNavAuditoria =
                new BotonPildora("  Auditoría Tickets", COLOR_CARD, COLOR_TEXT_MUTED);

        btnNavReportes =
                new BotonPildora("  Reportes", COLOR_CARD, COLOR_TEXT_MUTED);

        btnCerrarCaja =
                new BotonPildora("  Cerrar Caja", COLOR_RED, Color.WHITE);

        Dimension btnSize =
                new Dimension(200, 40);

        btnNavVentas.setMaximumSize(btnSize);
        btnNavInventario.setMaximumSize(btnSize);
        btnNavCompras.setMaximumSize(btnSize);
        btnNavDescuentos.setMaximumSize(btnSize);
        btnNavDevoluciones.setMaximumSize(btnSize);
        btnNavAuditoria.setMaximumSize(btnSize);
        btnNavReportes.setMaximumSize(btnSize);
        btnCerrarCaja.setMaximumSize(btnSize);

        btnNavVentas.setHorizontalAlignment(SwingConstants.LEFT);
        btnNavInventario.setHorizontalAlignment(SwingConstants.LEFT);
        btnNavCompras.setHorizontalAlignment(SwingConstants.LEFT);
        btnNavDescuentos.setHorizontalAlignment(SwingConstants.LEFT);
        btnNavDevoluciones.setHorizontalAlignment(SwingConstants.LEFT);
        btnNavAuditoria.setHorizontalAlignment(SwingConstants.LEFT);
        btnNavReportes.setHorizontalAlignment(SwingConstants.LEFT);
        btnCerrarCaja.setHorizontalAlignment(SwingConstants.LEFT);

        s.add(btnNavVentas);
        s.add(Box.createRigidArea(new Dimension(0, 10)));

        s.add(btnNavInventario);
        s.add(Box.createRigidArea(new Dimension(0, 10)));

        if (rolOperador.equalsIgnoreCase("ADMIN")) {

            s.add(btnNavCompras);
            s.add(Box.createRigidArea(new Dimension(0, 10)));

            s.add(btnNavDescuentos);
            s.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        s.add(btnNavDevoluciones);
        s.add(Box.createRigidArea(new Dimension(0, 10)));

        s.add(btnNavAuditoria);
        s.add(Box.createRigidArea(new Dimension(0, 10)));

        s.add(btnNavReportes);
        s.add(Box.createRigidArea(new Dimension(0, 25)));

        s.add(btnCerrarCaja);

        btnNavVentas.addActionListener(e -> {
            activarBoton(btnNavVentas);
            cardLayout.show(contentPanel, "VENTAS");
        });

        btnNavInventario.addActionListener(e -> {
            activarBoton(btnNavInventario);
            cardLayout.show(contentPanel, "INVENTARIO");
        });

        if (rolOperador.equalsIgnoreCase("ADMIN")) {

            btnNavCompras.addActionListener(e -> {
                activarBoton(btnNavCompras);
                cardLayout.show(contentPanel, "COMPRAS");
            });

            btnNavDescuentos.addActionListener(e -> {
                activarBoton(btnNavDescuentos);
                cardLayout.show(contentPanel, "DESCUENTOS");
            });
        }

        btnNavDevoluciones.addActionListener(e -> {
            activarBoton(btnNavDevoluciones);
            cardLayout.show(contentPanel, "DEVOLUCIONES");
        });

        btnNavAuditoria.addActionListener(e -> {
            activarBoton(btnNavAuditoria);
            cardLayout.show(contentPanel, "AUDITORIA");
        });

        btnNavReportes.addActionListener(e -> {
            activarBoton(btnNavReportes);
            cardLayout.show(contentPanel, "REPORTES");
        });

        return s;
    }

    private void activarBoton(JButton activo) {

        btnNavVentas.setBackground(COLOR_CARD);
        btnNavVentas.setForeground(COLOR_TEXT_MUTED);

        btnNavInventario.setBackground(COLOR_CARD);
        btnNavInventario.setForeground(COLOR_TEXT_MUTED);

        if (btnNavCompras != null) {

            btnNavCompras.setBackground(COLOR_CARD);
            btnNavCompras.setForeground(COLOR_TEXT_MUTED);
        }

        if (btnNavDescuentos != null) {

            btnNavDescuentos.setBackground(COLOR_CARD);
            btnNavDescuentos.setForeground(COLOR_TEXT_MUTED);
        }

        btnNavDevoluciones.setBackground(COLOR_CARD);
        btnNavDevoluciones.setForeground(COLOR_TEXT_MUTED);

        btnNavAuditoria.setBackground(COLOR_CARD);
        btnNavAuditoria.setForeground(COLOR_TEXT_MUTED);

        btnNavReportes.setBackground(COLOR_CARD);
        btnNavReportes.setForeground(COLOR_TEXT_MUTED);

        if (btnCerrarCaja != null) {

            btnCerrarCaja.setBackground(COLOR_RED);
            btnCerrarCaja.setForeground(Color.WHITE);
        }

        activo.setBackground(COLOR_GREEN);
        activo.setForeground(Color.WHITE);
    }

    private JPanel construirPanelVentas() {

        JPanel panel = new JPanel(new BorderLayout(18, 0));
        panel.setBackground(COLOR_BG);
        panel.setBorder(new EmptyBorder(18, 18, 18, 18));

        JPanel contenedorIzquierdo = new JPanel(new BorderLayout(0, 15));
        contenedorIzquierdo.setOpaque(false);

        PanelRedondeado barraSuperior = new PanelRedondeado(22, COLOR_PANEL);
        barraSuperior.setLayout(new BorderLayout(15, 0));
        barraSuperior.setBorder(new EmptyBorder(16, 18, 16, 18));

        JPanel busquedaPanel = new JPanel(new BorderLayout(10, 0));
        busquedaPanel.setOpaque(false);

        JLabel lblBuscar = new JLabel("Buscar producto");
        lblBuscar.setForeground(COLOR_TEXT_MUTED);
        lblBuscar.setFont(new Font("SansSerif", Font.BOLD, 12));

        txtBuscarProd.setPreferredSize(new Dimension(360, 38));
        configurarCampoPlano(txtBuscarProd, "Buscar por nombre o código");

        busquedaPanel.add(lblBuscar, BorderLayout.NORTH);
        busquedaPanel.add(txtBuscarProd, BorderLayout.CENTER);

        JPanel accionesBusqueda = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 12));
        accionesBusqueda.setOpaque(false);

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setForeground(COLOR_TEXT_LIGHT);
        lblCantidad.setFont(new Font("SansSerif", Font.BOLD, 12));

        cmbCategoriaVentas.setPreferredSize(new Dimension(150, 38));
        configurarCombo(cmbCategoriaVentas);

        JPanel controlCantidadVenta =
                crearControlCantidad(
                        txtCantidadVenta,
                        btnCantMenosVenta,
                        btnCantMasVenta
                );

        accionesBusqueda.add(cmbCategoriaVentas);
        accionesBusqueda.add(lblCantidad);
        accionesBusqueda.add(controlCantidadVenta);
        accionesBusqueda.add(btnAgregarCarrito);

        barraSuperior.add(busquedaPanel, BorderLayout.CENTER);
        barraSuperior.add(accionesBusqueda, BorderLayout.EAST);

        JPanel productosConTitulo = new JPanel(new BorderLayout(0, 12));
        productosConTitulo.setOpaque(false);

        JLabel lblCatalogo = new JLabel("CATÁLOGO DE PRODUCTOS");
        lblCatalogo.setForeground(COLOR_TEXT_LIGHT);
        lblCatalogo.setFont(new Font("SansSerif", Font.BOLD, 18));

        JLabel lblAyuda = new JLabel("Selecciona una tarjeta o busca un producto para agregarlo al resumen.");
        lblAyuda.setForeground(COLOR_TEXT_MUTED);
        lblAyuda.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JPanel encabezadoCatalogo = new JPanel(new GridLayout(2, 1));
        encabezadoCatalogo.setOpaque(false);
        encabezadoCatalogo.add(lblCatalogo);
        encabezadoCatalogo.add(lblAyuda);

        pnlGridProductos = new JPanel(new GridLayout(2, 0, 15, 15));
        pnlGridProductos.setBackground(COLOR_BG);

        JScrollPane scrollGrid =
                new JScrollPane(
                        pnlGridProductos,
                        JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
                );

        scrollGrid.setBorder(null);
        scrollGrid.getViewport().setBackground(COLOR_BG);
        scrollGrid.getHorizontalScrollBar().setUnitIncrement(20);
        scrollGrid.getHorizontalScrollBar().setBlockIncrement(180);

        productosConTitulo.add(encabezadoCatalogo, BorderLayout.NORTH);
        productosConTitulo.add(scrollGrid, BorderLayout.CENTER);

        contenedorIzquierdo.add(barraSuperior, BorderLayout.NORTH);
        contenedorIzquierdo.add(productosConTitulo, BorderLayout.CENTER);

        PanelRedondeado resumen = new PanelRedondeado(25, COLOR_CARD);
        resumen.setPreferredSize(new Dimension(370, 0));
        resumen.setLayout(new BorderLayout(0, 15));
        resumen.setBorder(new EmptyBorder(22, 20, 20, 20));

        JPanel encabezadoResumen = new JPanel(new BorderLayout());
        encabezadoResumen.setOpaque(false);

        JLabel tituloResumen = new JLabel("RESUMEN DE VENTA");
        tituloResumen.setForeground(COLOR_TEXT_LIGHT);
        tituloResumen.setFont(new Font("SansSerif", Font.BOLD, 17));

        JLabel subtituloResumen = new JLabel("Productos agregados al carrito");
        subtituloResumen.setForeground(COLOR_TEXT_MUTED);
        subtituloResumen.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JPanel textosResumen = new JPanel(new GridLayout(2, 1));
        textosResumen.setOpaque(false);
        textosResumen.add(tituloResumen);
        textosResumen.add(subtituloResumen);

        encabezadoResumen.add(textosResumen, BorderLayout.WEST);

        JButton btnIconoCarrito =
                new BotonPildora("🛒", COLOR_INPUT, COLOR_TEXT_LIGHT);

        btnIconoCarrito.setPreferredSize(new Dimension(45, 35));
        encabezadoResumen.add(btnIconoCarrito, BorderLayout.EAST);

        tablaCarrito.setFillsViewportHeight(true);
        tablaCarrito.setBackground(COLOR_CARD);
        tablaCarrito.setForeground(COLOR_TEXT_LIGHT);
        tablaCarrito.setSelectionBackground(new Color(30, 41, 59));
        tablaCarrito.setSelectionForeground(Color.WHITE);
        tablaCarrito.setGridColor(new Color(30, 41, 59));
        tablaCarrito.setRowHeight(36);
        tablaCarrito.setFont(new Font("SansSerif", Font.PLAIN, 12));

        tablaCarrito.getTableHeader().setBackground(new Color(30, 41, 59));
        tablaCarrito.getTableHeader().setForeground(COLOR_TEXT_LIGHT);
        tablaCarrito.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JScrollPane scrollCarrito = new JScrollPane(tablaCarrito);
        scrollCarrito.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59)));
        scrollCarrito.getViewport().setBackground(COLOR_CARD);

        JPanel panelAccionesCarrito = new JPanel(new GridLayout(1, 3, 8, 0));
        panelAccionesCarrito.setOpaque(false);

        btnQuitarUno.setFont(new Font("SansSerif", Font.BOLD, 18));
        btnEliminarProducto.setFont(new Font("SansSerif", Font.BOLD, 16));
        btnVaciarCarrito.setFont(new Font("SansSerif", Font.BOLD, 11));

        panelAccionesCarrito.add(btnQuitarUno);
        panelAccionesCarrito.add(btnEliminarProducto);
        panelAccionesCarrito.add(btnVaciarCarrito);

        JPanel panelCentroResumen = new JPanel(new BorderLayout(0, 10));
        panelCentroResumen.setOpaque(false);
        panelCentroResumen.add(scrollCarrito, BorderLayout.CENTER);
        panelCentroResumen.add(panelAccionesCarrito, BorderLayout.SOUTH);

        JPanel panelPago = new JPanel();
        panelPago.setOpaque(false);
        panelPago.setLayout(new BoxLayout(panelPago, BoxLayout.Y_AXIS));

        JLabel lblMetodo = crearEtiquetaPago("Método de Pago");
        configurarCombo(cmbMetodoPago);

        JLabel lblDescuento = crearEtiquetaPago("Descuento ($)");
        configurarCampoPago(txtDescuento);
        txtDescuento.setEditable(false);
        txtDescuento.setFocusable(false);
        txtDescuento.setText("0");

        JLabel lblEfectivo = crearEtiquetaPago("Efectivo Recibido");
        configurarCampoPago(txtEfectivo);

        JPanel filaCambio = new JPanel(new BorderLayout());
        filaCambio.setOpaque(false);

        JLabel lblCambioTitulo = new JLabel("Cambio");
        lblCambioTitulo.setForeground(COLOR_TEXT_MUTED);
        lblCambioTitulo.setFont(new Font("SansSerif", Font.BOLD, 12));

        lblCambio.setForeground(COLOR_GREEN);
        lblCambio.setFont(new Font("SansSerif", Font.BOLD, 18));

        filaCambio.add(lblCambioTitulo, BorderLayout.WEST);
        filaCambio.add(lblCambio, BorderLayout.EAST);

        JPanel filaTotal = new JPanel(new BorderLayout());
        filaTotal.setOpaque(false);
        filaTotal.setBorder(new EmptyBorder(10, 0, 10, 0));

        JLabel lblTotalTexto = new JLabel("TOTAL A PAGAR");
        lblTotalTexto.setForeground(COLOR_TEXT_MUTED);
        lblTotalTexto.setFont(new Font("SansSerif", Font.BOLD, 12));

        lblTotal.setForeground(Color.WHITE);
        lblTotal.setFont(new Font("SansSerif", Font.BOLD, 34));

        filaTotal.add(lblTotalTexto, BorderLayout.NORTH);
        filaTotal.add(lblTotal, BorderLayout.CENTER);

        panelPago.add(lblMetodo);
        panelPago.add(cmbMetodoPago);
        panelPago.add(Box.createRigidArea(new Dimension(0, 8)));
        panelPago.add(lblDescuento);
        panelPago.add(txtDescuento);
        panelPago.add(Box.createRigidArea(new Dimension(0, 8)));
        panelPago.add(lblEfectivo);
        panelPago.add(txtEfectivo);
        panelPago.add(Box.createRigidArea(new Dimension(0, 10)));
        panelPago.add(filaCambio);
        panelPago.add(Box.createRigidArea(new Dimension(0, 12)));
        panelPago.add(filaTotal);
        panelPago.add(Box.createRigidArea(new Dimension(0, 10)));

        btnCobrar.setPreferredSize(new Dimension(0, 45));
        btnCobrar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        panelPago.add(btnCobrar);

        resumen.add(encabezadoResumen, BorderLayout.NORTH);
        resumen.add(panelCentroResumen, BorderLayout.CENTER);
        resumen.add(panelPago, BorderLayout.SOUTH);

        panel.add(contenedorIzquierdo, BorderLayout.CENTER);
        panel.add(resumen, BorderLayout.EAST);

        return panel;
    }

    private JPanel construirPanelInventario() {

        JPanel pnl = new JPanel(new BorderLayout(20, 20));
        pnl.setBackground(COLOR_BG);
        pnl.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel topInventario = new JPanel(new BorderLayout(10, 0));
        topInventario.setOpaque(false);

        configurarCampoPlano(txtBuscarInventario, "Buscar producto en inventario");
        cmbCategoriaInventario.setPreferredSize(new Dimension(180, 35));

        topInventario.add(txtBuscarInventario, BorderLayout.CENTER);
        topInventario.add(cmbCategoriaInventario, BorderLayout.EAST);

        tablaInventario.setFillsViewportHeight(true);
        tablaInventario.setBackground(COLOR_CARD);
        tablaInventario.setForeground(COLOR_TEXT_LIGHT);
        tablaInventario.getTableHeader().setBackground(new Color(30, 41, 59));
        tablaInventario.getTableHeader().setForeground(COLOR_TEXT_LIGHT);

        JScrollPane scroll = new JScrollPane(tablaInventario);

        JPanel centro = new JPanel(new BorderLayout(0, 15));
        centro.setOpaque(false);
        centro.add(topInventario, BorderLayout.NORTH);
        centro.add(scroll, BorderLayout.CENTER);

        PanelRedondeado form = new PanelRedondeado(20, COLOR_CARD);
        form.setPreferredSize(new Dimension(310, 0));
        form.setLayout(new GridLayout(15, 1, 0, 8));
        form.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel titulo = new JLabel("GESTIÓN PRODUCTO");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 14));

        form.add(titulo);
        form.add(crearInputInv("ID / Código", txtInvId));
        form.add(crearInputInv("Nombre", txtInvNombre));
        form.add(crearInputInv("Categoría", txtInvCategoria));
        form.add(crearInputInv("Precio $", txtInvPrecio));
        form.add(crearInputInv("Stock Disponible", txtInvStock));

        form.add(
                crearControlCantidad(
                        txtInvStock,
                        btnInvStockMenos,
                        btnInvStockMas
                )
        );

        form.add(crearInputInv("Ruta Imagen", txtInvRutaImagen));
        form.add(btnSeleccionarImagen);
        form.add(btnInvAgregar);
        form.add(btnInvModificar);
        form.add(btnInvEliminar);

        pnl.add(centro, BorderLayout.CENTER);
        pnl.add(form, BorderLayout.EAST);

        return pnl;
    }

    private JPanel construirPanelCompras() {

        JPanel pnl = new JPanel(new BorderLayout(20, 20));
        pnl.setBackground(COLOR_BG);
        pnl.setBorder(new EmptyBorder(30, 30, 30, 30));

        PanelRedondeado form = new PanelRedondeado(25, COLOR_CARD);
        form.setPreferredSize(new Dimension(430, 0));
        form.setLayout(new GridLayout(13, 1, 0, 10));
        form.setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel titulo = new JLabel("PROVEEDORES / ENTRADA DE MERCANCÍA");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));

        form.add(titulo);
        form.add(crearInputInv("Código producto", txtCompraCodigo));
        form.add(crearInputInv("Proveedor", txtCompraProveedor));
        form.add(crearInputInv("Precio compra unitario", txtCompraPrecio));
        form.add(crearInputInv("Cantidad", txtCompraCantidad));

        form.add(
                crearControlCantidad(
                        txtCompraCantidad,
                        btnCompraMenos,
                        btnCompraMas
                )
        );

        form.add(btnRegistrarCompra);

        JLabel tituloCancelar = new JLabel("CANCELAR ENTRADA REGISTRADA");
        tituloCancelar.setForeground(Color.WHITE);
        tituloCancelar.setFont(new Font("SansSerif", Font.BOLD, 14));

        form.add(tituloCancelar);
        form.add(crearInputInv("ID entrada a cancelar", txtCompraIdCancelar));
        form.add(btnCancelarCompra);
        form.add(btnVerCompras);

        txtResultadoCompra.setBackground(COLOR_CARD);
        txtResultadoCompra.setForeground(Color.WHITE);
        txtResultadoCompra.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtResultadoCompra.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtResultadoCompra);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59), 2));

        pnl.add(form, BorderLayout.WEST);
        pnl.add(scroll, BorderLayout.CENTER);

        return pnl;
    }

    private JPanel construirPanelDescuentos() {

        JPanel pnl = new JPanel(new BorderLayout(20, 20));
        pnl.setBackground(COLOR_BG);
        pnl.setBorder(new EmptyBorder(30, 30, 30, 30));

        JPanel centro = new JPanel(new BorderLayout(0, 15));
        centro.setOpaque(false);

        JLabel titulo = new JLabel("ADMINISTRACIÓN DE DESCUENTOS");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 20));

        JLabel ayuda = new JLabel("Solo ADMIN puede crear, actualizar o eliminar descuentos para productos y proveedores.");
        ayuda.setForeground(COLOR_TEXT_MUTED);
        ayuda.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel encabezado = new JPanel(new GridLayout(2, 1));
        encabezado.setOpaque(false);
        encabezado.add(titulo);
        encabezado.add(ayuda);

        tablaDescuentos.setFillsViewportHeight(true);
        tablaDescuentos.setRowHeight(32);
        tablaDescuentos.setBackground(COLOR_CARD);
        tablaDescuentos.setForeground(COLOR_TEXT_LIGHT);
        tablaDescuentos.setSelectionBackground(new Color(30, 41, 59));
        tablaDescuentos.setSelectionForeground(Color.WHITE);
        tablaDescuentos.setGridColor(new Color(30, 41, 59));

        tablaDescuentos.getTableHeader().setBackground(new Color(30, 41, 59));
        tablaDescuentos.getTableHeader().setForeground(COLOR_TEXT_LIGHT);
        tablaDescuentos.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JScrollPane scroll = new JScrollPane(tablaDescuentos);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59), 2));

        centro.add(encabezado, BorderLayout.NORTH);
        centro.add(scroll, BorderLayout.CENTER);

        PanelRedondeado form = new PanelRedondeado(25, COLOR_CARD);
        form.setPreferredSize(new Dimension(340, 0));
        form.setLayout(new GridLayout(14, 1, 0, 8));
        form.setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel tituloForm = new JLabel("DATOS DEL DESCUENTO");
        tituloForm.setForeground(Color.WHITE);
        tituloForm.setFont(new Font("SansSerif", Font.BOLD, 16));

        txtDescId.setEditable(false);

        chkDescActivo.setOpaque(false);
        chkDescActivo.setForeground(Color.WHITE);
        chkDescActivo.setFont(new Font("SansSerif", Font.BOLD, 12));

        configurarCombo(cmbDescAmbito);
        configurarCombo(cmbDescTipo);

        form.add(tituloForm);
        form.add(crearInputInv("ID", txtDescId));
        form.add(crearInputInv("Nombre descuento", txtDescNombre));
        form.add(cmbDescAmbito);
        form.add(cmbDescTipo);
        form.add(crearInputInv("Valor", txtDescValor));
        form.add(chkDescActivo);
        form.add(btnDescNuevo);
        form.add(btnDescGuardar);
        form.add(btnDescActualizar);
        form.add(btnDescEliminar);
        form.add(btnDescRecargar);

        pnl.add(centro, BorderLayout.CENTER);
        pnl.add(form, BorderLayout.EAST);

        return pnl;
    }

    private JPanel construirPanelDevoluciones() {

        JPanel pnl = new JPanel(new BorderLayout(20, 20));
        pnl.setBackground(COLOR_BG);
        pnl.setBorder(new EmptyBorder(30, 30, 30, 30));

        PanelRedondeado form = new PanelRedondeado(25, COLOR_CARD);
        form.setPreferredSize(new Dimension(430, 0));
        form.setLayout(new GridLayout(11, 1, 0, 12));
        form.setBorder(new EmptyBorder(25, 25, 25, 25));

        JLabel titulo = new JLabel("DEVOLUCIÓN DE PRODUCTOS");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 18));

        form.add(titulo);
        form.add(crearInputInv("Folio de venta", txtDevFolio));
        form.add(crearInputInv("Código producto", txtDevCodigo));
        form.add(crearInputInv("Cantidad", txtDevCantidad));

        form.add(
                crearControlCantidad(
                        txtDevCantidad,
                        btnDevCantidadMenos,
                        btnDevCantidadMas
                )
        );

        form.add(crearInputInv("Motivo", txtDevMotivo));
        form.add(btnRegistrarDevolucion);
        form.add(btnVerDevoluciones);

        txtResultadoDevolucion.setBackground(COLOR_CARD);
        txtResultadoDevolucion.setForeground(Color.WHITE);
        txtResultadoDevolucion.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtResultadoDevolucion.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtResultadoDevolucion);
        scroll.setBorder(
                BorderFactory.createLineBorder(
                        new Color(30, 41, 59),
                        2
                )
        );

        pnl.add(form, BorderLayout.WEST);
        pnl.add(scroll, BorderLayout.CENTER);

        return pnl;
    }

    private JPanel construirPanelAuditoriaTickets() {

        JPanel pnl = new JPanel(new BorderLayout(20, 20));
        pnl.setBackground(COLOR_BG);
        pnl.setBorder(new EmptyBorder(30, 30, 30, 30));

        JPanel controles = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controles.setOpaque(false);

        JLabel lbl = new JLabel("Seleccione Folio de Venta: ");
        lbl.setForeground(Color.WHITE);

        cmbTicketsGenerados.setPreferredSize(new Dimension(200, 30));

        controles.add(lbl);
        controles.add(cmbTicketsGenerados);
        controles.add(btnVerTicket);

        txtVisorTicket.setBackground(COLOR_CARD);
        txtVisorTicket.setForeground(Color.WHITE);
        txtVisorTicket.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtVisorTicket.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtVisorTicket);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59), 2));

        pnl.add(controles, BorderLayout.NORTH);
        pnl.add(scroll, BorderLayout.CENTER);

        return pnl;
    }

    private JPanel construirPanelReportes() {

        JPanel pnl = new JPanel(new BorderLayout(20, 20));
        pnl.setBackground(COLOR_BG);
        pnl.setBorder(new EmptyBorder(30, 30, 30, 30));

        JPanel controles = new JPanel();
        controles.setOpaque(false);
        controles.setLayout(new GridLayout(3, 1, 0, 10));

        JPanel filaFechaUnica = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filaFechaUnica.setOpaque(false);

        JLabel lblFecha = new JLabel("Fecha dd/MM/yyyy: ");
        lblFecha.setForeground(Color.WHITE);

        txtFechaReporte.setPreferredSize(new Dimension(130, 30));
        txtFechaReporte.setText("20/05/2026");

        filaFechaUnica.add(lblFecha);
        filaFechaUnica.add(txtFechaReporte);
        filaFechaUnica.add(btnReporteFecha);
        filaFechaUnica.add(btnExportarReporte);
        filaFechaUnica.add(btnReporteProductosVendidos);
        filaFechaUnica.add(btnExportarProductosVendidos);
        filaFechaUnica.add(btnReporteStockBajo);

        JPanel filaIntervalo = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filaIntervalo.setOpaque(false);

        JLabel lblInicio = new JLabel("Inicio dd/MM/yyyy:");
        lblInicio.setForeground(Color.WHITE);

        JLabel lblFin = new JLabel("Fin dd/MM/yyyy:");
        lblFin.setForeground(Color.WHITE);

        txtFechaInicioReporte.setPreferredSize(new Dimension(130, 30));
        txtFechaInicioReporte.setText("20/05/2026");

        txtFechaFinReporte.setPreferredSize(new Dimension(130, 30));
        txtFechaFinReporte.setText("20/05/2026");

        filaIntervalo.add(lblInicio);
        filaIntervalo.add(txtFechaInicioReporte);
        filaIntervalo.add(lblFin);
        filaIntervalo.add(txtFechaFinReporte);
        filaIntervalo.add(btnReporteIntervalo);
        filaIntervalo.add(btnExportarIntervalo);

        JPanel filaAyuda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filaAyuda.setOpaque(false);

        JLabel lblAyuda = new JLabel(
                "Usa REPORTE POR FECHA para un día exacto o REPORTE INTERVALO para varias fechas."
        );

        lblAyuda.setForeground(COLOR_TEXT_MUTED);
        lblAyuda.setFont(new Font("SansSerif", Font.PLAIN, 12));

        filaAyuda.add(lblAyuda);

        controles.add(filaFechaUnica);
        controles.add(filaIntervalo);
        controles.add(filaAyuda);

        JTextArea txtInfo = txtVisorTicket;
        txtInfo.setBackground(COLOR_CARD);
        txtInfo.setForeground(Color.WHITE);
        txtInfo.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtInfo.setEditable(false);

        JScrollPane scroll = new JScrollPane(txtInfo);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(30, 41, 59), 2));

        pnl.add(controles, BorderLayout.NORTH);
        pnl.add(scroll, BorderLayout.CENTER);

        return pnl;
    }

    private JLabel crearEtiquetaPago(String texto) {

        JLabel lbl = new JLabel(texto);
        lbl.setForeground(COLOR_TEXT_MUTED);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private void configurarCampoPlano(JTextField txt, String tooltip) {

        txt.setToolTipText(tooltip);
        txt.setBackground(COLOR_INPUT);
        txt.setForeground(COLOR_TEXT_LIGHT);
        txt.setCaretColor(Color.WHITE);
        txt.setFont(new Font("SansSerif", Font.PLAIN, 13));
        txt.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDER),
                        new EmptyBorder(8, 12, 8, 12)
                )
        );
    }

    private void configurarCampoPago(JTextField txt) {

        txt.setBackground(COLOR_INPUT);
        txt.setForeground(Color.WHITE);
        txt.setCaretColor(Color.WHITE);
        txt.setFont(new Font("SansSerif", Font.BOLD, 13));
        txt.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        txt.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDER),
                        new EmptyBorder(6, 10, 6, 10)
                )
        );
    }

    private void configurarCombo(JComboBox<String> combo) {

        combo.setBackground(COLOR_INPUT);
        combo.setForeground(Color.WHITE);
        combo.setFont(new Font("SansSerif", Font.BOLD, 12));
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        combo.setBorder(BorderFactory.createLineBorder(COLOR_BORDER));
    }

    private JPanel crearControlCantidad(
            JTextField txt,
            JButton btnMenos,
            JButton btnMas
    ) {

        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(140, 35));

        txt.setHorizontalAlignment(JTextField.CENTER);
        txt.setBackground(COLOR_INPUT);
        txt.setForeground(Color.WHITE);
        txt.setCaretColor(Color.WHITE);
        txt.setFont(new Font("SansSerif", Font.BOLD, 14));
        txt.setBorder(
                BorderFactory.createLineBorder(
                        COLOR_BORDER
                )
        );

        btnMenos.setPreferredSize(new Dimension(40, 35));
        btnMas.setPreferredSize(new Dimension(40, 35));

        panel.add(btnMenos, BorderLayout.WEST);
        panel.add(txt, BorderLayout.CENTER);
        panel.add(btnMas, BorderLayout.EAST);

        return panel;
    }

    private JPanel crearInputInv(String titulo, JTextField txt) {

        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);

        txt.setBackground(COLOR_INPUT);
        txt.setForeground(Color.WHITE);
        txt.setCaretColor(Color.WHITE);

        txt.setBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(Color.GRAY),
                        titulo,
                        0,
                        0,
                        null,
                        COLOR_TEXT_MUTED
                )
        );

        p.add(txt, BorderLayout.CENTER);

        return p;
    }

    public class PanelRedondeado extends JPanel {

        private int r;
        private Color c;

        public PanelRedondeado(int r, Color c) {

            this.r = r;
            this.c = c;

            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {

            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(c);

            g2.fill(
                    new RoundRectangle2D.Double(
                            0,
                            0,
                            getWidth(),
                            getHeight(),
                            r,
                            r
                    )
            );

            g2.dispose();
        }
    }

    public class BotonPildora extends JButton {

        private Color bg;

        public BotonPildora(String t, Color bg, Color fg) {

            super(t);

            this.bg = bg;

            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setForeground(fg);
            setFont(new Font("SansSerif", Font.BOLD, 12));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        public void setBackground(Color bg) {

            this.bg = bg;

            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 = (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(bg);

            int h = getHeight();

            g2.fill(
                    new RoundRectangle2D.Double(
                            0,
                            0,
                            getWidth(),
                            getHeight(),
                            h,
                            h
                    )
            );

            g2.dispose();

            super.paintComponent(g);
        }
    }
}