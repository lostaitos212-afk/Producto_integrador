package main.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class LoginView extends JFrame {

    public JButton btnAdmin;
    public JButton btnCajero;

    public JPasswordField txtPasswordAdmin = new JPasswordField();

    public JLabel lblMensaje = new JLabel("Seleccione modo de acceso", SwingConstants.CENTER);

    private final Color COLOR_BG = new Color(8, 10, 18);
    private final Color COLOR_CARD = new Color(15, 23, 42);
    private final Color COLOR_GREEN = new Color(16, 185, 129);
    private final Color COLOR_BLUE = new Color(59, 130, 246);
    private final Color COLOR_TEXT_MUTED = new Color(148, 163, 184);

    public LoginView() {

        setTitle("MEGAPOS - Acceso");
        setSize(430, 430);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COLOR_BG);
        setLayout(new GridBagLayout());

        PanelRedondeado card =
                new PanelRedondeado(30, COLOR_CARD);

        card.setPreferredSize(new Dimension(340, 330));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(35, 30, 35, 30));

        JLabel lblTitulo =
                new JLabel("MEGAPOS");

        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSub =
                new JLabel("Seleccione el tipo de acceso");

        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblSub.setForeground(COLOR_TEXT_MUTED);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnAdmin =
                new BotonPildora("ADMIN", COLOR_BLUE, Color.WHITE);

        btnCajero =
                new BotonPildora("CAJERO", COLOR_GREEN, Color.WHITE);

        btnAdmin.setMaximumSize(new Dimension(260, 42));
        btnCajero.setMaximumSize(new Dimension(260, 42));

        btnAdmin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCajero.setAlignmentX(Component.CENTER_ALIGNMENT);

        txtPasswordAdmin.setMaximumSize(new Dimension(260, 38));
        txtPasswordAdmin.setHorizontalAlignment(JTextField.CENTER);
        txtPasswordAdmin.setBackground(new Color(30, 41, 59));
        txtPasswordAdmin.setForeground(Color.WHITE);
        txtPasswordAdmin.setCaretColor(Color.WHITE);
        txtPasswordAdmin.setVisible(false);

        txtPasswordAdmin.setBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(new Color(51, 65, 85)),
                        "Contraseña Admin",
                        0,
                        0,
                        new Font("SansSerif", Font.PLAIN, 10),
                        Color.LIGHT_GRAY
                )
        );

        lblMensaje.setForeground(COLOR_TEXT_MUTED);
        lblMensaje.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblMensaje.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(lblTitulo);
        card.add(Box.createRigidArea(new Dimension(0, 8)));
        card.add(lblSub);
        card.add(Box.createRigidArea(new Dimension(0, 28)));
        card.add(btnAdmin);
        card.add(Box.createRigidArea(new Dimension(0, 12)));
        card.add(btnCajero);
        card.add(Box.createRigidArea(new Dimension(0, 18)));
        card.add(txtPasswordAdmin);
        card.add(Box.createRigidArea(new Dimension(0, 12)));
        card.add(lblMensaje);

        add(card);
    }

    class PanelRedondeado extends JPanel {

        private int r;
        private Color c;

        public PanelRedondeado(int r, Color c) {

            this.r = r;
            this.c = c;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 =
                    (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(c);

            g2.fill(
                    new RoundRectangle2D.Double(
                            0,
                            0,
                            getWidth(),
                            getHeight(),
                            r,
                            r
                    )
            );

            g2.dispose();

            super.paintComponent(g);
        }
    }

    class BotonPildora extends JButton {

        private Color bg;

        public BotonPildora(String t, Color bg, Color fg) {

            super(t);

            this.bg = bg;

            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setForeground(fg);
            setFont(new Font("SansSerif", Font.BOLD, 13));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {

            Graphics2D g2 =
                    (Graphics2D) g.create();

            g2.setRenderingHint(
                    RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setColor(bg);

            int h =
                    getHeight();

            g2.fill(
                    new RoundRectangle2D.Double(
                            0,
                            0,
                            getWidth(),
                            h,
                            h,
                            h
                    )
            );

            g2.dispose();

            super.paintComponent(g);
        }
    }
}