package main.model;

import java.util.ArrayList;
import java.util.List;

public class Venta {

    private String folio;
    private double subtotal;
    private double descuento;
    private double total;
    private String metodoPago;
    private double montoRecibido;
    private double cambio;
    private String fecha;
    private String hora;
    private List<DetalleVenta> detalles;

    public Venta(
            String folio,
            double subtotal,
            double descuento,
            double total,
            String metodoPago,
            double montoRecibido,
            double cambio,
            String fecha,
            String hora,
            List<DetalleVenta> detalles
    ) {

        this.folio = folio;
        this.subtotal = subtotal;
        this.descuento = descuento;
        this.total = total;
        this.metodoPago = metodoPago;
        this.montoRecibido = montoRecibido;
        this.cambio = cambio;
        this.fecha = fecha;
        this.hora = hora;

        if (detalles == null) {
            this.detalles = new ArrayList<>();
        } else {
            this.detalles = detalles;
        }
    }

    public Venta(
            String folio,
            double subtotal,
            double descuento,
            double total,
            String metodoPago,
            double cambio,
            String fecha,
            String hora,
            List<DetalleVenta> detalles
    ) {

        this(
                folio,
                subtotal,
                descuento,
                total,
                metodoPago,
                total,
                cambio,
                fecha,
                hora,
                detalles
        );
    }

    public String getFolio() {
        return folio;
    }

    public void setFolio(String folio) {
        this.folio = folio;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public double getMontoRecibido() {
        return montoRecibido;
    }

    public void setMontoRecibido(double montoRecibido) {
        this.montoRecibido = montoRecibido;
    }

    public double getCambio() {
        return cambio;
    }

    public void setCambio(double cambio) {
        this.cambio = cambio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public List<DetalleVenta> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleVenta> detalles) {

        if (detalles == null) {
            this.detalles = new ArrayList<>();
        } else {
            this.detalles = detalles;
        }
    }
}