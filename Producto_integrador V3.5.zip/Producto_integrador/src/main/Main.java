package main;

import main.view.LoginView;
import main.controller.LoginController;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            LoginView loginView =
                    new LoginView();

            new LoginController(loginView);

            loginView.setVisible(true);
        });
    }
}