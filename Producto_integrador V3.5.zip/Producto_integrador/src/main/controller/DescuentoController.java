package main.controller;

import main.dao.DescuentoDAO;
import main.view.MainView;

import javax.swing.JOptionPane;

public class DescuentoController {

    private MainView vista;

    private String rol;

    private DescuentoDAO descuentoDAO =
            new DescuentoDAO();

    public DescuentoController(
            MainView vista,
            String rol
    ) {

        this.vista =
                vista;

        this.rol =
                rol;

        descuentoDAO.asegurarTablaYDatosBase();

        if (rol.equalsIgnoreCase("ADMIN")) {

            prepararPanelDescuentos();
        }
    }

    private void prepararPanelDescuentos() {

        cargarDescuentos();

        if (vista.btnDescNuevo != null) {

            vista.btnDescNuevo.addActionListener(e -> limpiarFormulario());
        }

        if (vista.btnDescGuardar != null) {

            vista.btnDescGuardar.addActionListener(e -> guardarNuevo());
        }

        if (vista.btnDescActualizar != null) {

            vista.btnDescActualizar.addActionListener(e -> actualizarSeleccionado());
        }

        if (vista.btnDescEliminar != null) {

            vista.btnDescEliminar.addActionListener(e -> eliminarSeleccionado());
        }

        if (vista.btnDescRecargar != null) {

            vista.btnDescRecargar.addActionListener(e -> cargarDescuentos());
        }

        if (vista.tablaDescuentos != null) {

            vista.tablaDescuentos
                    .getSelectionModel()
                    .addListSelectionListener(e -> {

                        if (e.getValueIsAdjusting() == false) {

                            llenarFormularioDesdeTabla();
                        }
                    });
        }
    }

    private void cargarDescuentos() {

        vista.tablaDescuentos.setModel(
                descuentoDAO.obtenerModeloDescuentos()
        );
    }

    private void llenarFormularioDesdeTabla() {

        int fila =
                vista.tablaDescuentos
                        .getSelectedRow();

        if (fila < 0) {

            return;
        }

        vista.txtDescId.setText(
                vista.tablaDescuentos
                        .getValueAt(fila, 0)
                        .toString()
        );

        vista.txtDescNombre.setText(
                vista.tablaDescuentos
                        .getValueAt(fila, 1)
                        .toString()
        );

        vista.cmbDescAmbito.setSelectedItem(
                vista.tablaDescuentos
                        .getValueAt(fila, 2)
                        .toString()
        );

        vista.cmbDescTipo.setSelectedItem(
                vista.tablaDescuentos
                        .getValueAt(fila, 3)
                        .toString()
        );

        vista.txtDescValor.setText(
                vista.tablaDescuentos
                        .getValueAt(fila, 4)
                        .toString()
        );

        String activo =
                vista.tablaDescuentos
                        .getValueAt(fila, 5)
                        .toString();

        vista.chkDescActivo.setSelected(
                activo.equalsIgnoreCase("Sí")
        );
    }

    private void limpiarFormulario() {

        vista.txtDescId.setText("");
        vista.txtDescNombre.setText("");
        vista.cmbDescAmbito.setSelectedIndex(0);
        vista.cmbDescTipo.setSelectedIndex(0);
        vista.txtDescValor.setText("0");
        vista.chkDescActivo.setSelected(true);
        vista.tablaDescuentos.clearSelection();
    }

    private boolean validarFormulario() {

        if (vista.txtDescNombre
                .getText()
                .trim()
                .isEmpty()) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Ingrese el nombre del descuento."
            );

            return false;
        }

        try {

            Double.parseDouble(
                    vista.txtDescValor
                            .getText()
                            .trim()
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    vista,
                    "El valor debe ser numérico."
            );

            return false;
        }

        return true;
    }

    private void guardarNuevo() {

        if (validarFormulario() == false) {

            return;
        }

        String nombre =
                vista.txtDescNombre
                        .getText()
                        .trim();

        String ambito =
                vista.cmbDescAmbito
                        .getSelectedItem()
                        .toString();

        String tipo =
                vista.cmbDescTipo
                        .getSelectedItem()
                        .toString();

        double valor =
                Double.parseDouble(
                        vista.txtDescValor
                                .getText()
                                .trim()
                );

        boolean activo =
                vista.chkDescActivo
                        .isSelected();

        boolean ok =
                descuentoDAO.agregarDescuento(
                        nombre,
                        ambito,
                        tipo,
                        valor,
                        activo
                );

        if (ok) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Descuento agregado correctamente."
            );

            cargarDescuentos();
            limpiarFormulario();

        } else {

            JOptionPane.showMessageDialog(
                    vista,
                    "No se pudo agregar el descuento."
            );
        }
    }

    private void actualizarSeleccionado() {

        if (vista.txtDescId
                .getText()
                .trim()
                .isEmpty()) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Seleccione un descuento de la tabla."
            );

            return;
        }

        if (validarFormulario() == false) {

            return;
        }

        int id =
                Integer.parseInt(
                        vista.txtDescId
                                .getText()
                                .trim()
                );

        String nombre =
                vista.txtDescNombre
                        .getText()
                        .trim();

        String ambito =
                vista.cmbDescAmbito
                        .getSelectedItem()
                        .toString();

        String tipo =
                vista.cmbDescTipo
                        .getSelectedItem()
                        .toString();

        double valor =
                Double.parseDouble(
                        vista.txtDescValor
                                .getText()
                                .trim()
                );

        boolean activo =
                vista.chkDescActivo
                        .isSelected();

        boolean ok =
                descuentoDAO.actualizarDescuento(
                        id,
                        nombre,
                        ambito,
                        tipo,
                        valor,
                        activo
                );

        if (ok) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Descuento actualizado correctamente."
            );

            cargarDescuentos();

        } else {

            JOptionPane.showMessageDialog(
                    vista,
                    "No se pudo actualizar el descuento."
            );
        }
    }

    private void eliminarSeleccionado() {

        if (vista.txtDescId
                .getText()
                .trim()
                .isEmpty()) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Seleccione un descuento de la tabla."
            );

            return;
        }

        int respuesta =
                JOptionPane.showConfirmDialog(
                        vista,
                        "¿Seguro que deseas eliminar este descuento?",
                        "Confirmar eliminación",
                        JOptionPane.YES_NO_OPTION
                );

        if (respuesta != JOptionPane.YES_OPTION) {

            return;
        }

        int id =
                Integer.parseInt(
                        vista.txtDescId
                                .getText()
                                .trim()
                );

        boolean ok =
                descuentoDAO.eliminarDescuento(id);

        if (ok) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Descuento eliminado correctamente."
            );

            cargarDescuentos();
            limpiarFormulario();

        } else {

            JOptionPane.showMessageDialog(
                    vista,
                    "No se pudo eliminar el descuento."
            );
        }
    }
}