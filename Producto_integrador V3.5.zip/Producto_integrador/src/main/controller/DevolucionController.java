package main.controller;

import main.dao.DevolucionDAO;
import main.view.MainView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class DevolucionController implements ActionListener {

    private MainView vista;

    private DevolucionDAO devolucionDAO =
            new DevolucionDAO();

    public DevolucionController(MainView vista) {

        this.vista =
                vista;

        vista.btnRegistrarDevolucion.addActionListener(this);
        vista.btnVerDevoluciones.addActionListener(this);
        vista.btnDevCantidadMenos.addActionListener(this);
        vista.btnDevCantidadMas.addActionListener(this);

        vista.btnNavDevoluciones.addActionListener(e -> cargarHistorial());
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnRegistrarDevolucion) {

            registrarDevolucion();

        } else if (e.getSource() == vista.btnVerDevoluciones) {

            cargarHistorial();

        } else if (e.getSource() == vista.btnDevCantidadMenos) {

            cambiarCantidad(-1);

        } else if (e.getSource() == vista.btnDevCantidadMas) {

            cambiarCantidad(1);
        }
    }

    private void cambiarCantidad(int cambio) {

        try {

            String texto =
                    vista.txtDevCantidad
                            .getText()
                            .trim();

            int cantidad;

            if (texto.isEmpty()) {

                cantidad =
                        1;

            } else {

                cantidad =
                        Integer.parseInt(texto);
            }

            cantidad += cambio;

            if (cantidad < 1) {

                cantidad =
                        1;
            }

            vista.txtDevCantidad.setText(
                    String.valueOf(cantidad)
            );

        } catch (NumberFormatException e) {

            vista.txtDevCantidad.setText("1");
        }
    }

    private void registrarDevolucion() {

        try {

            String folio =
                    vista.txtDevFolio
                            .getText()
                            .trim();

            String codigo =
                    vista.txtDevCodigo
                            .getText()
                            .trim();

            String textoCantidad =
                    vista.txtDevCantidad
                            .getText()
                            .trim();

            String motivo =
                    vista.txtDevMotivo
                            .getText()
                            .trim();

            if (folio.isEmpty()
                    || codigo.isEmpty()
                    || textoCantidad.isEmpty()
                    || motivo.isEmpty()) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Complete todos los campos de devolución."
                );

                return;
            }

            int cantidad =
                    Integer.parseInt(textoCantidad);

            if (cantidad <= 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "La cantidad debe ser mayor a 0."
                );

                return;
            }

            int cantidadVendida =
                    devolucionDAO.obtenerCantidadVendida(
                            folio,
                            codigo
                    );

            if (cantidadVendida == 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Ese producto no pertenece a la venta indicada.\nVerifique el folio y el código."
                );

                return;
            }

            int cantidadDevuelta =
                    devolucionDAO.obtenerCantidadDevuelta(
                            folio,
                            codigo
                    );

            int cantidadDisponible =
                    cantidadVendida - cantidadDevuelta;

            if (cantidadDisponible <= 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Ese producto ya fue devuelto completamente."
                );

                return;
            }

            if (cantidad > cantidadDisponible) {

                JOptionPane.showMessageDialog(
                        vista,
                        "No puede devolver más unidades de las disponibles.\n\n"
                                + "Vendidas: "
                                + cantidadVendida
                                + "\nYa devueltas: "
                                + cantidadDevuelta
                                + "\nDisponibles para devolver: "
                                + cantidadDisponible
                );

                return;
            }

            boolean registrado =
                    devolucionDAO.registrarDevolucion(
                            folio,
                            codigo,
                            cantidad,
                            motivo
                    );

            if (registrado) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Devolución registrada correctamente.\n"
                                + "El stock fue actualizado y el reembolso quedó registrado."
                );

                limpiarCampos();

                cargarHistorial();

            } else {

                JOptionPane.showMessageDialog(
                        vista,
                        "No se pudo registrar la devolución.\nVerifique los datos."
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    vista,
                    "La cantidad debe ser numérica."
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Error al registrar devolución."
            );

            e.printStackTrace();
        }
    }

    private void cargarHistorial() {

        String historial =
                devolucionDAO.obtenerResumenDevoluciones();

        vista.txtResultadoDevolucion.setText(historial);
    }

    private void limpiarCampos() {

        vista.txtDevFolio.setText("");
        vista.txtDevCodigo.setText("");
        vista.txtDevCantidad.setText("1");
        vista.txtDevMotivo.setText("");
    }
}