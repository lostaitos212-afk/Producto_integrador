package main.controller;

import main.dao.VentaDAO;
import main.view.MainView;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.List;

import javax.swing.JOptionPane;

public class AuditoriaController implements ActionListener {

    private MainView vista;

    private VentaDAO ventaDAO =
            new VentaDAO();

    private boolean cargandoFolios =
            false;

    public AuditoriaController(MainView vista) {

        this.vista =
                vista;

        prepararVisualAuditoria();

        if (vista.btnNavAuditoria != null) {

            vista.btnNavAuditoria.addActionListener(e -> {

                prepararVisualAuditoria();

                cargarFoliosTickets();

                vista.cardLayout.show(
                        vista.contentPanel,
                        "AUDITORIA"
                );
            });
        }

        if (vista.btnVerTicket != null) {

            vista.btnVerTicket.addActionListener(this);
        }

        if (vista.cmbTicketsGenerados != null) {

            vista.cmbTicketsGenerados.addActionListener(e -> {

                if (cargandoFolios == false) {

                    visualizarTicketSeleccionado();
                }
            });
        }

        cargarFoliosTickets();
    }

    private void prepararVisualAuditoria() {

        if (vista.txtVisorTicket != null) {

            vista.txtVisorTicket.setOpaque(true);

            vista.txtVisorTicket.setBackground(
                    vista.COLOR_CARD
            );

            vista.txtVisorTicket.setForeground(
                    Color.WHITE
            );

            vista.txtVisorTicket.setCaretColor(
                    Color.WHITE
            );

            vista.txtVisorTicket.setFont(
                    new Font(
                            "Monospaced",
                            Font.PLAIN,
                            14
                    )
            );

            vista.txtVisorTicket.setEditable(false);
        }

        if (vista.cmbTicketsGenerados != null) {

            vista.cmbTicketsGenerados.setBackground(
                    vista.COLOR_INPUT
            );

            vista.cmbTicketsGenerados.setForeground(
                    Color.WHITE
            );

            vista.cmbTicketsGenerados.setFont(
                    new Font(
                            "SansSerif",
                            Font.BOLD,
                            12
                    )
            );
        }
    }

    private void cargarFoliosTickets() {

        cargandoFolios =
                true;

        vista.cmbTicketsGenerados.removeAllItems();

        List<String> folios =
                ventaDAO.obtenerFolios();

        for (String folio : folios) {

            vista.cmbTicketsGenerados.addItem(folio);
        }

        cargandoFolios =
                false;

        if (vista.cmbTicketsGenerados.getItemCount() > 0) {

            vista.cmbTicketsGenerados.setSelectedIndex(0);

            visualizarTicketSeleccionado();

        } else {

            vista.txtVisorTicket.setText(
                    "========================================\n"
                            + "          AUDITORÍA DE TICKETS          \n"
                            + "========================================\n\n"
                            + "No hay tickets registrados todavía.\n\n"
                            + "Cuando realices una venta, aquí podrás:\n"
                            + "- Visualizar el ticket.\n"
                            + "- Revisar folio, fecha y hora.\n"
                            + "- Reimprimir o consultar la venta.\n"
            );
        }
    }

    private void visualizarTicketSeleccionado() {

        if (vista.cmbTicketsGenerados.getSelectedItem() == null) {

            vista.txtVisorTicket.setText(
                    "No hay ningún ticket seleccionado."
            );

            return;
        }

        String folio =
                vista.cmbTicketsGenerados
                        .getSelectedItem()
                        .toString();

        String ticket =
                ventaDAO.obtenerTicketPorFolio(
                        folio
                );

        if (ticket == null
                || ticket.trim().isEmpty()) {

            vista.txtVisorTicket.setText(
                    "No se pudo cargar el ticket con folio: "
                            + folio
            );

            return;
        }

        vista.txtVisorTicket.setText(ticket);

        vista.txtVisorTicket.setCaretPosition(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnVerTicket) {

            if (vista.cmbTicketsGenerados.getItemCount() == 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "No hay tickets registrados."
                );

                return;
            }

            visualizarTicketSeleccionado();
        }
    }
}