package main.controller;

import main.dao.CajaDAO;
import main.view.LoginView;
import main.view.MainView;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class CierreCajaController implements ActionListener {

    private MainView vista;

    private String rol;

    private double cajaInicial;

    private CajaDAO cajaDAO =
            new CajaDAO();

    public CierreCajaController(
            MainView vista,
            String rol,
            double cajaInicial
    ) {

        this.vista =
                vista;

        this.rol =
                rol;

        this.cajaInicial =
                cajaInicial;

        if (vista.btnCerrarCaja != null) {

            vista.btnCerrarCaja.addActionListener(this);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        cerrarCaja();
    }

    private void cerrarCaja() {

        int confirmar =
                JOptionPane.showConfirmDialog(
                        vista,
                        "¿Deseas cerrar la caja del día?\n\n"
                                + "Se generará un registro con:\n"
                                + "- Ventas del día\n"
                                + "- Tickets generados\n"
                                + "- Caja inicial\n"
                                + "- Total final en caja\n\n"
                                + "Después de cerrar caja regresarás al inicio.",
                        "Confirmar cierre de caja",
                        JOptionPane.YES_NO_OPTION
                );

        if (confirmar != JOptionPane.YES_OPTION) {

            return;
        }

        String reporte =
                cajaDAO.generarCierreCaja(
                        rol,
                        cajaInicial
                );

        mostrarReporteCierre(reporte);

        regresarAlInicio();
    }

    private void mostrarReporteCierre(String reporte) {

        JTextArea area =
                new JTextArea(reporte);

        area.setEditable(false);
        area.setLineWrap(false);
        area.setWrapStyleWord(false);

        JScrollPane scroll =
                new JScrollPane(area);

        scroll.setPreferredSize(
                new Dimension(520, 420)
        );

        JOptionPane.showMessageDialog(
                vista,
                scroll,
                "Cierre de caja generado",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void regresarAlInicio() {

        vista.dispose();

        LoginView login =
                new LoginView();

        new LoginController(login);

        login.setVisible(true);
    }
}