package main.controller;

import main.dao.CompraDAO;
import main.view.MainView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class CompraController implements ActionListener {

    private MainView vista;

    private CompraDAO compraDAO =
            new CompraDAO();

    public CompraController(MainView vista) {

        this.vista = vista;

        if (vista.btnRegistrarCompra != null) {
            vista.btnRegistrarCompra.addActionListener(this);
        }

        if (vista.btnCompraMenos != null) {
            vista.btnCompraMenos.addActionListener(this);
        }

        if (vista.btnCompraMas != null) {
            vista.btnCompraMas.addActionListener(this);
        }

        if (vista.btnVerCompras != null) {
            vista.btnVerCompras.addActionListener(this);
        }

        if (vista.btnCancelarCompra != null) {
            vista.btnCancelarCompra.addActionListener(this);
        }

        cargarHistorialCompras();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnCompraMenos) {

            cambiarCantidadCompra(-1);

        } else if (e.getSource() == vista.btnCompraMas) {

            cambiarCantidadCompra(1);

        } else if (e.getSource() == vista.btnRegistrarCompra) {

            registrarEntradaProveedor();

        } else if (e.getSource() == vista.btnVerCompras) {

            cargarHistorialCompras();

        } else if (e.getSource() == vista.btnCancelarCompra) {

            cancelarEntrada();
        }
    }

    private void cambiarCantidadCompra(int cambio) {

        try {

            String texto =
                    vista.txtCompraCantidad
                            .getText()
                            .trim();

            int cantidad;

            if (texto.isEmpty()) {

                cantidad = 1;

            } else {

                cantidad =
                        Integer.parseInt(texto);
            }

            cantidad += cambio;

            if (cantidad < 1) {

                cantidad = 1;
            }

            vista.txtCompraCantidad.setText(
                    String.valueOf(cantidad)
            );

        } catch (NumberFormatException e) {

            vista.txtCompraCantidad.setText("1");
        }
    }

    private void registrarEntradaProveedor() {

        try {

            String codigo =
                    vista.txtCompraCodigo
                            .getText()
                            .trim();

            String proveedor =
                    vista.txtCompraProveedor
                            .getText()
                            .trim();

            String cantidadTexto =
                    vista.txtCompraCantidad
                            .getText()
                            .trim();

            String precioTexto =
                    vista.txtCompraPrecio
                            .getText()
                            .trim();

            if (codigo.isEmpty()
                    || proveedor.isEmpty()
                    || cantidadTexto.isEmpty()
                    || precioTexto.isEmpty()) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Complete todos los campos de la entrada."
                );

                return;
            }

            int cantidad =
                    Integer.parseInt(cantidadTexto);

            double precioCompra =
                    Double.parseDouble(precioTexto);

            if (cantidad <= 0 || precioCompra < 0) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Cantidad y precio deben ser válidos."
                );

                return;
            }

            boolean ok =
                    compraDAO.registrarEntradaMercancia(
                            codigo,
                            cantidad,
                            precioCompra,
                            proveedor
                    );

            if (ok) {

                String mensaje =
                        "ENTRADA DE PROVEEDOR REGISTRADA CORRECTAMENTE\n\n"
                                + "Código producto: "
                                + codigo
                                + "\nProveedor: "
                                + proveedor
                                + "\nCantidad agregada: "
                                + cantidad
                                + "\nPrecio compra unitario: $"
                                + precioCompra
                                + "\nTotal entrada: $"
                                + (cantidad * precioCompra)
                                + "\n\n"
                                + "El stock fue aumentado correctamente.";

                vista.txtResultadoCompra.setText(mensaje);

                JOptionPane.showMessageDialog(
                        vista,
                        "Entrada de mercancía registrada."
                );

                limpiarCamposEntrada();

                cargarHistorialCompras();

            } else {

                JOptionPane.showMessageDialog(
                        vista,
                        "No se pudo registrar la entrada.\nVerifique que el producto exista."
                );
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Cantidad y precio deben ser numéricos."
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Error al registrar entrada."
            );

            ex.printStackTrace();
        }
    }

    private void cancelarEntrada() {

        String textoId =
                vista.txtCompraIdCancelar
                        .getText()
                        .trim();

        if (textoId.isEmpty()) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Ingrese el ID de la entrada que desea cancelar."
            );

            return;
        }

        try {

            int idCompra =
                    Integer.parseInt(textoId);

            boolean existe =
                    compraDAO.compraExiste(idCompra);

            if (existe == false) {

                JOptionPane.showMessageDialog(
                        vista,
                        "No existe una entrada con ese ID."
                );

                return;
            }

            String detalle =
                    compraDAO.obtenerDetalleCancelacion(idCompra);

            int confirmar =
                    JOptionPane.showConfirmDialog(
                            vista,
                            "Se cancelará la siguiente entrada:\n\n"
                                    + detalle
                                    + "\nEsta acción restará del stock los productos de esa entrada.\n\n"
                                    + "¿Deseas continuar?",
                            "Confirmar cancelación de entrada",
                            JOptionPane.YES_NO_OPTION
                    );

            if (confirmar != JOptionPane.YES_OPTION) {

                return;
            }

            boolean cancelada =
                    compraDAO.cancelarCompra(idCompra);

            if (cancelada) {

                JOptionPane.showMessageDialog(
                        vista,
                        "Entrada cancelada correctamente.\nEl stock fue actualizado."
                );

                vista.txtCompraIdCancelar.setText("");

                cargarHistorialCompras();

            } else {

                JOptionPane.showMessageDialog(
                        vista,
                        "No se pudo cancelar la entrada.\n"
                                + "Puede que no haya stock suficiente para retirar."
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    vista,
                    "El ID de entrada debe ser numérico."
            );

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    vista,
                    "Error al cancelar entrada."
            );

            e.printStackTrace();
        }
    }

    private void cargarHistorialCompras() {

        String historial =
                compraDAO.obtenerResumenCompras();

        vista.txtResultadoCompra.setText(historial);
    }

    private void limpiarCamposEntrada() {

        vista.txtCompraCodigo.setText("");
        vista.txtCompraProveedor.setText("");
        vista.txtCompraCantidad.setText("1");
        vista.txtCompraPrecio.setText("");
    }
}