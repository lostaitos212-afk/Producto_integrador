package main.controller;

import main.view.LoginView;
import main.view.MainView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class LoginController implements ActionListener {

    private LoginView vistaLogin;

    private boolean esperandoPasswordAdmin =
            false;

    public LoginController(LoginView vistaLogin) {

        this.vistaLogin =
                vistaLogin;

        if (vistaLogin.btnAdmin != null) {
            vistaLogin.btnAdmin.addActionListener(this);
        }

        if (vistaLogin.btnCajero != null) {
            vistaLogin.btnCajero.addActionListener(this);
        }

        if (vistaLogin.txtPasswordAdmin != null) {
            vistaLogin.txtPasswordAdmin.addActionListener(this);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vistaLogin.btnCajero) {

            abrirSistema(
                    "CAJERO",
                    1000.0
            );

            return;
        }

        if (e.getSource() == vistaLogin.btnAdmin) {

            if (esperandoPasswordAdmin == false) {

                esperandoPasswordAdmin =
                        true;

                vistaLogin.txtPasswordAdmin.setVisible(true);
                vistaLogin.lblMensaje.setText("Ingrese contraseña de administrador");
                vistaLogin.txtPasswordAdmin.requestFocus();

                vistaLogin.revalidate();
                vistaLogin.repaint();

                return;
            }

            validarAdmin();

            return;
        }

        if (e.getSource() == vistaLogin.txtPasswordAdmin) {

            validarAdmin();
        }
    }

    private void validarAdmin() {

        String pass =
                new String(
                        vistaLogin.txtPasswordAdmin
                                .getPassword()
                );

        if (pass.equals("1234")) {

            abrirSistema(
                    "ADMIN",
                    100000.0
            );

        } else {

            JOptionPane.showMessageDialog(
                    vistaLogin,
                    "Contraseña incorrecta.",
                    "Acceso denegado",
                    JOptionPane.ERROR_MESSAGE
            );

            vistaLogin.txtPasswordAdmin.setText("");
            vistaLogin.txtPasswordAdmin.requestFocus();
        }
    }

    private void abrirSistema(
            String rol,
            double cajaInicial
    ) {

        vistaLogin.dispose();

        MainView vistaPrincipal =
                new MainView(
                        rol,
                        cajaInicial
                );

        new VentaController(vistaPrincipal);
        new InventarioController(vistaPrincipal);
        new DevolucionController(vistaPrincipal);
        new AuditoriaController(vistaPrincipal);

        if (rol.equalsIgnoreCase("ADMIN")) {

            new CompraController(vistaPrincipal);
            new DescuentoController(vistaPrincipal, rol);
        }

        new CierreCajaController(
                vistaPrincipal,
                rol,
                cajaInicial
        );

        vistaPrincipal.setVisible(true);
    }
}